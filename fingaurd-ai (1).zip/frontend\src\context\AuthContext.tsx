import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, AuthResponse } from '../types';
import { authService } from '../services/api';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  loading: boolean;
  login: (email: string, pass: string) => Promise<void>;
  register: (name: string, email: string, pass: string) => Promise<void>;
  loginAsDemo: () => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('fingaurd_token'));
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchUser = async () => {
      const params = new URLSearchParams(window.location.search);
      let currentToken = token;
      if (params.get('demo') === 'true' && !currentToken) {
        try {
          const demoData = await authService.demoLogin();
          handleAuthSuccess(demoData);
          setLoading(false);
          return;
        } catch (e) {
          console.error('Auto demo login failed', e);
        }
      }

      if (!currentToken) {
        setLoading(false);
        return;
      }
      try {
        const u = await authService.getMe();
        setUser(u);
      } catch (err) {
        localStorage.removeItem('fingaurd_token');
        setToken(null);
        setUser(null);
      } finally {
        setLoading(false);
      }
    };
    fetchUser();
  }, [token]);

  const handleAuthSuccess = (data: AuthResponse) => {
    localStorage.setItem('fingaurd_token', data.token);
    setToken(data.token);
    setUser({
      userId: data.userId,
      name: data.name,
      email: data.email,
      role: data.role,
      createdAt: new Date().toISOString(),
    });
  };

  const login = async (email: string, pass: string) => {
    const data = await authService.login({ email, password: pass });
    handleAuthSuccess(data);
  };

  const register = async (name: string, email: string, pass: string) => {
    const data = await authService.register({ name, email, password: pass });
    handleAuthSuccess(data);
  };

  const loginAsDemo = async () => {
    const data = await authService.demoLogin();
    handleAuthSuccess(data);
  };

  const logout = () => {
    localStorage.removeItem('fingaurd_token');
    setToken(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!user,
        loading,
        login,
        register,
        loginAsDemo,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
