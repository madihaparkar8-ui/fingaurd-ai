package com.fingaurd.repository;

import com.fingaurd.model.Journey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface JourneyRepository extends JpaRepository<Journey, Long> {
    Optional<Journey> findTopByUser_UserIdOrderByJourneyIdDesc(Long userId);
    List<Journey> findByUser_UserId(Long userId);
    void deleteByUser_UserId(Long userId);
}
