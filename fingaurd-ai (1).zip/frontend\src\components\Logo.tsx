import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  showTagline?: boolean;
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({ size = 'md', showTagline = false, className = '' }) => {
  const iconSizes = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-12 h-12',
  };

  const textSizes = {
    sm: 'text-lg',
    md: 'text-xl',
    lg: 'text-2xl',
  };

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Original Shield with Rising Trajectory Line */}
      <svg
        className={`${iconSizes[size]} text-brand-primary drop-shadow-sm flex-shrink-0`}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Shield Outer Boundary */}
        <path
          d="M50 8L88 22V48C88 71.5 72 90 50 96C28 90 12 71.5 12 48V22L50 8Z"
          fill="#1F5F5B"
          stroke="#1F5F5B"
          strokeWidth="2"
        />
        {/* Shield Inner Gradient Soft Fill */}
        <path
          d="M50 14L82 26V48C82 68 68.5 84 50 89.5C31.5 84 18 68 18 48V26L50 14Z"
          fill="url(#shield_gradient)"
          opacity="0.35"
        />
        {/* Rising Commitment Trajectory Path Line with Breakthrough Point */}
        <path
          d="M26 68L40 56L54 62L74 32"
          stroke="#C9A24A"
          strokeWidth="5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {/* Guarding Point / Signal Marker */}
        <circle cx="74" cy="32" r="5.5" fill="#FFFFFF" stroke="#C9A24A" strokeWidth="3" />
        <circle cx="40" cy="56" r="3.5" fill="#FFFFFF" opacity="0.9" />
        <circle cx="54" cy="62" r="3.5" fill="#FFFFFF" opacity="0.9" />

        <defs>
          <linearGradient id="shield_gradient" x1="50" y1="14" x2="50" y2="90" gradientUnits="userSpaceOnUse">
            <stop stopColor="#FFFFFF" stopOpacity="0.8" />
            <stop offset="1" stopColor="#1F5F5B" stopOpacity="0.1" />
          </linearGradient>
        </defs>
      </svg>

      <div className="flex flex-col leading-none">
        <span className={`font-heading font-extrabold tracking-tight text-[#0F1F2E] dark:text-white ${textSizes[size]}`}>
          Fingaurd <span className="text-[#1F5F5B]">AI</span>
        </span>
        {showTagline && (
          <span className="text-[11px] font-medium text-[#5B6B7A] tracking-wider uppercase mt-1">
            Pause before you commit.
          </span>
        )}
      </div>
    </div>
  );
};

export default Logo;
