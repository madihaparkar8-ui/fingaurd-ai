package com.fingaurd.dto.response;

public class AnomalyEnsembleDto {

    private Double zScoreSignal;
    private Double stepChangeSignal;
    private Double maxRatioSignal;
    private Double anomalyScore;

    // Raw supporting indicators
    private Double zScore;
    private Double maxStepRatio;
    private Double historicalMaxRatio;
    private Double velocityPerDay;
    private Double entityConcentration;
    private Boolean returnFollowedByEscalation;

    public AnomalyEnsembleDto() {}

    public Double getzScoreSignal() {
        return zScoreSignal;
    }

    public void setzScoreSignal(Double zScoreSignal) {
        this.zScoreSignal = zScoreSignal;
    }

    public Double getStepChangeSignal() {
        return stepChangeSignal;
    }

    public void setStepChangeSignal(Double stepChangeSignal) {
        this.stepChangeSignal = stepChangeSignal;
    }

    public Double getMaxRatioSignal() {
        return maxRatioSignal;
    }

    public void setMaxRatioSignal(Double maxRatioSignal) {
        this.maxRatioSignal = maxRatioSignal;
    }

    public Double getAnomalyScore() {
        return anomalyScore;
    }

    public void setAnomalyScore(Double anomalyScore) {
        this.anomalyScore = anomalyScore;
    }

    public Double getzScore() {
        return zScore;
    }

    public void setzScore(Double zScore) {
        this.zScore = zScore;
    }

    public Double getMaxStepRatio() {
        return maxStepRatio;
    }

    public void setMaxStepRatio(Double maxStepRatio) {
        this.maxStepRatio = maxStepRatio;
    }

    public Double getHistoricalMaxRatio() {
        return historicalMaxRatio;
    }

    public void setHistoricalMaxRatio(Double historicalMaxRatio) {
        this.historicalMaxRatio = historicalMaxRatio;
    }

    public Double getVelocityPerDay() {
        return velocityPerDay;
    }

    public void setVelocityPerDay(Double velocityPerDay) {
        this.velocityPerDay = velocityPerDay;
    }

    public Double getEntityConcentration() {
        return entityConcentration;
    }

    public void setEntityConcentration(Double entityConcentration) {
        this.entityConcentration = entityConcentration;
    }

    public Boolean getReturnFollowedByEscalation() {
        return returnFollowedByEscalation;
    }

    public void setReturnFollowedByEscalation(Boolean returnFollowedByEscalation) {
        this.returnFollowedByEscalation = returnFollowedByEscalation;
    }
}
