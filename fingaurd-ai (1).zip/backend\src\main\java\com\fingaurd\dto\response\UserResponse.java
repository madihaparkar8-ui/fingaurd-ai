package com.fingaurd.dto.response;

import com.fingaurd.model.Role;
import com.fingaurd.model.User;
import java.time.LocalDateTime;

public class UserResponse {

    private Long userId;
    private String name;
    private String email;
    private Role role;
    private LocalDateTime createdAt;

    public UserResponse() {}

    public UserResponse(Long userId, String name, String email, Role role, LocalDateTime createdAt) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.role = role;
        this.createdAt = createdAt;
    }

    public static UserResponse fromEntity(User user) {
        if (user == null) return null;
        return new UserResponse(user.getUserId(), user.getName(), user.getEmail(), user.getRole(), user.getCreatedAt());
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
