package com.fingaurd.dto.response;

import java.util.ArrayList;
import java.util.List;

public class InfluenceCategoryDto {

    private String category;
    private String label;
    private Double confidence;
    private List<String> matchedEvidence = new ArrayList<>();

    public InfluenceCategoryDto() {}

    public InfluenceCategoryDto(String category, String label, Double confidence, List<String> matchedEvidence) {
        this.category = category;
        this.label = label;
        this.confidence = confidence;
        this.matchedEvidence = matchedEvidence != null ? matchedEvidence : new ArrayList<>();
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Double getConfidence() {
        return confidence;
    }

    public void setConfidence(Double confidence) {
        this.confidence = confidence;
    }

    public List<String> getMatchedEvidence() {
        return matchedEvidence;
    }

    public void setMatchedEvidence(List<String> matchedEvidence) {
        this.matchedEvidence = matchedEvidence;
    }
}
