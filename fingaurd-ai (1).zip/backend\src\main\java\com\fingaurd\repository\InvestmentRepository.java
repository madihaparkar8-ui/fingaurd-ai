package com.fingaurd.repository;

import com.fingaurd.model.Investment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface InvestmentRepository extends JpaRepository<Investment, Long> {
    List<Investment> findByUser_UserIdOrderByInvestedOnAsc(Long userId);
    List<Investment> findByUser_UserIdOrderByInvestedOnDesc(Long userId);
    Optional<Investment> findByInvestmentIdAndUser_UserId(Long investmentId, Long userId);
    void deleteByUser_UserId(Long userId);
}
