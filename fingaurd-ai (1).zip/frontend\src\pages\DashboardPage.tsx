import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { journeyService, investmentService, riskService } from '../services/api';
import { Journey, Investment, RiskReport } from '../types';
import { formatINR, formatDate, getRiskBandDetails } from '../utils/formatters';
import { RiskGauge } from '../components/RiskGauge';
import {
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell,
  LineChart, Line
} from 'recharts';
import {
  ShieldAlert, TrendingUp, Landmark, ShieldCheck,
  ArrowRight, AlertTriangle, Building2, Calendar, Brain
} from 'lucide-react';

const ENTITY_COLORS = ['#1F5F5B', '#C9A24A', '#5FA37A', '#D9784A', '#8E67AA', '#4A8BB2'];

export const DashboardPage: React.FC = () => {
  const { user } = useAuth();
  const [journey, setJourney] = useState<Journey | null>(null);
  const [investments, setInvestments] = useState<Investment[]>([]);
  const [reports, setReports] = useState<RiskReport[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        setLoading(true);
        const [jData, invData, repData] = await Promise.all([
          journeyService.getMyJourney().catch(() => null),
          investmentService.getAll().catch(() => []),
          riskService.getHistory().catch(() => []),
        ]);
        setJourney(jData);
        setInvestments(invData);
        setReports(repData);
      } catch (err) {
        console.error('Failed to load dashboard data', err);
      } finally {
        setLoading(false);
      }
    };
    loadDashboardData();
  }, []);

  const latestReport = reports.length > 0 ? reports[0] : null;
  const latestScore = latestReport ? latestReport.overallScore : (journey?.eventCount ? 73 : 0);
  const band = getRiskBandDetails(latestScore);

  // Prepare Area Chart Data (Cumulative exposure over time)
  let cumulative = 0;
  const areaChartData = [...investments]
    .sort((a, b) => new Date(a.investedOn).getTime() - new Date(b.investedOn).getTime())
    .map((inv) => {
      cumulative += Number(inv.amount);
      return {
        date: formatDate(inv.investedOn),
        amount: Number(inv.amount),
        cumulative: cumulative,
        entity: inv.entityName,
      };
    });

  // If there is a latest proposed report, append as a simulated commitment point
  if (latestReport) {
    areaChartData.push({
      date: 'Proposed',
      amount: Number(latestReport.targetInvestment),
      cumulative: cumulative + Number(latestReport.targetInvestment),
      entity: latestReport.targetEntity + ' (Proposed)',
    });
  }

  // Prepare Donut Chart Data (Entity concentration)
  const entityTotalsMap: { [key: string]: number } = {};
  investments.forEach((inv) => {
    entityTotalsMap[inv.entityName] = (entityTotalsMap[inv.entityName] || 0) + Number(inv.amount);
  });
  const donutData = Object.entries(entityTotalsMap).map(([name, value]) => ({
    name,
    value,
  }));

  // Prepare Risk Trend Data
  const trendData = [...reports].reverse().map((r, i) => ({
    index: `#${i + 1}`,
    date: formatDate(r.createdAt),
    score: r.overallScore,
    entity: r.targetEntity,
  }));

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-10 bg-gray-200 rounded-xl w-64" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-28 bg-gray-200 rounded-2xl" />
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 h-96 bg-gray-200 rounded-2xl" />
          <div className="lg:col-span-4 h-96 bg-gray-200 rounded-2xl" />
        </div>
      </div>
    );
  }

  const uniqueEntities = new Set(investments.map((i) => i.entityName)).size;

  return (
    <div className="space-y-8">
      {/* Header Greeting & Primary CTA Card */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-heading font-black tracking-tight text-[#0F1F2E]">
            Welcome back, {user?.name || 'Investor'}
          </h1>
          <p className="text-xs sm:text-sm text-[#5B6B7A] mt-0.5">
            Your behavioral baseline and pre-commitment risk intelligence center.
          </p>
        </div>

        <Link
          to="/analyse"
          className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold bg-[#1F5F5B] text-white hover:bg-[#2A7A74] transition-all shadow-fin-hover"
        >
          <ShieldAlert className="w-4 h-4 text-[#C9A24A]" />
          <span>Run Pre-Commitment Check</span>
        </Link>
      </div>

      {/* Behavioural Friction Alert Banner if Cognitive Biases Detected on Latest Report */}
      {latestReport?.behaviouralBiases && latestReport.behaviouralBiases.length > 0 && (
        <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200/80 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-start sm:items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center flex-shrink-0">
              <Brain className="w-4 h-4" />
            </div>
            <div>
              <div className="font-extrabold text-[#0F1F2E] flex items-center gap-2">
                <span>Behavioural Friction Alert: {latestReport.behaviouralBiases.length} Cognitive Risk Factors Active</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-200 text-amber-900 uppercase">
                  Pre-Commitment Notice
                </span>
              </div>
              <p className="text-[11px] text-[#5B6B7A] mt-0.5">
                Targeting <strong className="text-[#0F1F2E]">{latestReport.targetEntity}</strong> ({formatINR(latestReport.targetInvestment)}): {latestReport.behaviouralBiases.map((b) => b.title).join(' • ')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-center flex-shrink-0">
            <Link
              to={`/reports?id=${latestReport.reportId}`}
              className="px-3 py-1.5 rounded-lg font-bold text-xs bg-white border border-amber-300 text-amber-900 hover:bg-amber-100/60 transition-colors shadow-2xs"
            >
              View Biases & Evidence
            </Link>
            <Link
              to={`/pause?id=${latestReport.reportId}`}
              className="px-3.5 py-1.5 rounded-lg font-bold text-xs bg-[#B4414B] text-white hover:bg-[#9B333C] transition-colors shadow-2xs flex items-center gap-1"
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              Pause Checklist
            </Link>
          </div>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        <div className="p-5 rounded-2xl bg-white border border-[#E4E8E4] shadow-fin-card space-y-1">
          <div className="flex items-center justify-between text-xs text-[#5B6B7A]">
            <span>Total Exposure</span>
            <Landmark className="w-4 h-4 text-[#1F5F5B]" />
          </div>
          <div className="text-2xl font-black font-heading text-[#0F1F2E] font-tabular">
            {formatINR(journey?.totalExposure || 0)}
          </div>
          <div className="text-[11px] text-[#5B6B7A]">
            Across {journey?.eventCount || 0} recorded commitments
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-[#E4E8E4] shadow-fin-card space-y-1">
          <div className="flex items-center justify-between text-xs text-[#5B6B7A]">
            <span>Largest Single Commitment</span>
            <TrendingUp className="w-4 h-4 text-[#C9A24A]" />
          </div>
          <div className="text-2xl font-black font-heading text-[#0F1F2E] font-tabular">
            {formatINR(journey?.maxSingleCommitment || 0)}
          </div>
          <div className="text-[11px] text-[#5B6B7A]">Historical personal maximum</div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-[#E4E8E4] shadow-fin-card space-y-1">
          <div className="flex items-center justify-between text-xs text-[#5B6B7A]">
            <span>Active Entities</span>
            <Building2 className="w-4 h-4 text-[#5FA37A]" />
          </div>
          <div className="text-2xl font-black font-heading text-[#0F1F2E] font-tabular">
            {uniqueEntities}
          </div>
          <div className="text-[11px] text-[#5B6B7A]">Recipient firms / platforms</div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-[#E4E8E4] shadow-fin-card space-y-1">
          <div className="flex items-center justify-between text-xs text-[#5B6B7A]">
            <span>Latest Risk Index</span>
            <ShieldCheck className="w-4 h-4" style={{ color: band.color }} />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black font-heading text-[#0F1F2E] font-tabular">
              {latestScore}
            </span>
            <span
              className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider"
              style={{ backgroundColor: band.bgColor, color: band.color }}
            >
              {band.label}
            </span>
          </div>
          <div className="text-[11px] text-[#5B6B7A] truncate">
            {latestReport ? `Target: ${latestReport.targetEntity}` : 'Initial baseline evaluated'}
          </div>
        </div>
      </div>

      {/* Hero Visual Row: Exposure Area Chart + Semi-Circular Risk Gauge */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Cumulative Exposure Over Time (Area Chart) */}
        <div className="lg:col-span-7 bg-white p-6 rounded-fin border border-[#E4E8E4] shadow-fin-card flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-heading font-extrabold text-base text-[#0F1F2E]">
                Commitment Journey & Cumulative Exposure
              </h3>
              <p className="text-xs text-[#5B6B7A]">
                Historical trajectory with proposed commitment highlighted.
              </p>
            </div>
            <Link
              to="/journey"
              className="text-xs font-semibold text-[#1F5F5B] hover:underline flex items-center gap-1"
            >
              Replay Timeline <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="h-64 w-full">
            {areaChartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={areaChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorExposure" x1="0" y1="0" x2="0" y2="1">
                      <stop stopColor="#1F5F5B" stopOpacity={0.4} />
                      <stop stopColor="#1F5F5B" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#5B6B7A' }} />
                  <YAxis
                    tick={{ fontSize: 11, fill: '#5B6B7A' }}
                    tickFormatter={(v) => `₹${v >= 100000 ? (v / 100000).toFixed(1) + 'L' : v >= 1000 ? (v / 1000).toFixed(0) + 'k' : v}`}
                  />
                  <Tooltip
                    formatter={(val: any) => [formatINR(Number(val)), 'Cumulative Exposure']}
                    labelFormatter={(label) => `Stage: ${label}`}
                    contentStyle={{ borderRadius: '12px', border: '1px solid #E4E8E4', fontSize: '12px' }}
                  />
                  <Area
                    type="monotone"
                    dataKey="cumulative"
                    stroke="#1F5F5B"
                    strokeWidth={2.5}
                    fillOpacity={1}
                    fill="url(#colorExposure)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-[#5B6B7A]">
                No investments logged yet.
              </div>
            )}
          </div>
        </div>

        {/* Hero Semi-Circular Risk Gauge Card */}
        <div className="lg:col-span-5 bg-white p-6 rounded-fin border border-[#E4E8E4] shadow-fin-card flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h3 className="font-heading font-extrabold text-base text-[#0F1F2E]">
                Active Manipulation Risk Index
              </h3>
              <p className="text-xs text-[#5B6B7A]">
                Behavioral anomaly fusion index (0–100).
              </p>
            </div>
            {latestReport && (
              <Link
                to={`/reports?id=${latestReport.reportId}`}
                className="text-xs font-semibold text-[#1F5F5B] hover:underline"
              >
                Full Report
              </Link>
            )}
          </div>

          <div className="py-2 flex justify-center">
            <RiskGauge score={latestScore} size={270} animate={true} />
          </div>

          {latestReport ? (
            <div className="mt-2 p-3 rounded-xl bg-[#F5F6F3] border border-[#E4E8E4] flex items-center justify-between text-xs">
              <span className="text-[#5B6B7A]">
                Target: <strong className="text-[#0F1F2E]">{latestReport.targetEntity}</strong> ({formatINR(latestReport.targetInvestment)})
              </span>
              <Link
                to={`/pause?id=${latestReport.reportId}`}
                className="font-bold text-[#B4414B] hover:underline flex items-center gap-1"
              >
                Pause Screen <AlertTriangle className="w-3.5 h-3.5" />
              </Link>
            </div>
          ) : (
            <div className="mt-2 text-center text-xs text-[#5B6B7A]">
              Load the demo preset or run your first pre-commitment check.
            </div>
          )}
        </div>
      </div>

      {/* Second Row: Entity Concentration Donut + Risk History Trend */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Entity Concentration Donut */}
        <div className="lg:col-span-5 bg-white p-6 rounded-fin border border-[#E4E8E4] shadow-fin-card">
          <div className="mb-4">
            <h3 className="font-heading font-extrabold text-base text-[#0F1F2E]">
              Entity Capital Concentration
            </h3>
            <p className="text-xs text-[#5B6B7A]">
              Portfolio distribution across counterparties.
            </p>
          </div>

          <div className="h-56 w-full flex items-center justify-center">
            {donutData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={donutData}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={80}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {donutData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={ENTITY_COLORS[index % ENTITY_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(val: any) => [formatINR(Number(val)), 'Total Exposure']}
                    contentStyle={{ borderRadius: '12px', border: '1px solid #E4E8E4', fontSize: '12px' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <span className="text-xs text-[#5B6B7A]">No entity exposure records</span>
            )}
          </div>

          <div className="space-y-1.5 mt-2">
            {donutData.slice(0, 3).map((item, idx) => (
              <div key={idx} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: ENTITY_COLORS[idx % ENTITY_COLORS.length] }} />
                  <span className="text-[#0F1F2E] font-medium truncate max-w-[150px]">{item.name}</span>
                </div>
                <span className="font-bold text-[#0F1F2E] font-tabular">{formatINR(item.value)}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Risk History Trend Line */}
        <div className="lg:col-span-7 bg-white p-6 rounded-fin border border-[#E4E8E4] shadow-fin-card flex flex-col justify-between">
          <div className="mb-4">
            <h3 className="font-heading font-extrabold text-base text-[#0F1F2E]">
              Pre-Commitment Risk History Trend
            </h3>
            <p className="text-xs text-[#5B6B7A]">
              Evolution of calculated risk index across pre-commitment queries.
            </p>
          </div>

          <div className="h-56 w-full">
            {trendData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={trendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#5B6B7A' }} />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: '#5B6B7A' }} />
                  <Tooltip
                    formatter={(val: any) => [`${val} / 100`, 'Risk Index']}
                    labelFormatter={(label) => `Assessment Date: ${label}`}
                    contentStyle={{ borderRadius: '12px', border: '1px solid #E4E8E4', fontSize: '12px' }}
                  />
                  <Line
                    type="monotone"
                    dataKey="score"
                    stroke="#D9784A"
                    strokeWidth={3}
                    dot={{ r: 5, fill: '#FFFFFF', stroke: '#D9784A', strokeWidth: 2 }}
                    activeDot={{ r: 7 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-[#5B6B7A]">
                No reports in history yet. Run a check to record assessments.
              </div>
            )}
          </div>

          <div className="pt-2 text-[11px] text-[#5B6B7A] text-right">
            Values ≥ 76 indicate CRITICAL threshold requiring verification.
          </div>
        </div>
      </div>

      {/* Third Row: Recent Investments List & Call-to-Action Card */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 bg-white p-6 rounded-fin border border-[#E4E8E4] shadow-fin-card">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-heading font-extrabold text-base text-[#0F1F2E]">
                Recent Investment Commitments
              </h3>
              <p className="text-xs text-[#5B6B7A]">
                Chronological record forming your decision journey baseline.
              </p>
            </div>
            <Link to="/investments" className="text-xs font-semibold text-[#1F5F5B] hover:underline">
              View All Table
            </Link>
          </div>

          <div className="divide-y divide-[#E4E8E4]">
            {investments.slice(0, 5).map((inv) => (
              <div key={inv.investmentId} className="py-3 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-[#E3F0EE] text-[#1F5F5B] flex items-center justify-center font-bold text-xs">
                    {inv.entityName.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-bold text-xs text-[#0F1F2E]">{inv.entityName}</h4>
                    <div className="flex items-center gap-2 text-[11px] text-[#5B6B7A]">
                      <Calendar className="w-3 h-3" />
                      <span>{formatDate(inv.investedOn)}</span>
                      <span>•</span>
                      <span>{inv.type}</span>
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="font-bold text-xs text-[#0F1F2E] font-tabular">
                    {formatINR(inv.amount)}
                  </div>
                  {inv.returnAmount ? (
                    <span className="text-[10px] text-[#5FA37A] font-medium">
                      Payout: {formatINR(inv.returnAmount)}
                    </span>
                  ) : (
                    <span className="text-[10px] text-[#5B6B7A] uppercase font-medium">
                      {inv.status}
                    </span>
                  )}
                </div>
              </div>
            ))}

            {investments.length === 0 && (
              <div className="py-8 text-center text-xs text-[#5B6B7A]">
                No investments found. Go to the Investments tab or click "Demo Journeys" above.
              </div>
            )}
          </div>
        </div>

        {/* Call to Action Card */}
        <div className="lg:col-span-4 bg-gradient-to-br from-[#1F5F5B] to-[#143F3C] p-6 rounded-fin text-white shadow-fin-hover flex flex-col justify-between">
          <div className="space-y-3">
            <span className="inline-block px-3 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-white/15 text-[#C9A24A]">
              Pre-Commitment Intervention
            </span>
            <h3 className="font-heading font-black text-xl leading-tight">
              Planning a big commitment?
            </h3>
            <p className="text-xs text-white/80 leading-relaxed">
              Before transferring capital to any advisory or scheme, check if the proposed amount triggers high-escalation, rapid velocity, or coercive urgency markers.
            </p>
          </div>

          <div className="pt-6">
            <Link
              to="/analyse"
              className="w-full py-3 px-4 rounded-xl font-bold text-xs bg-[#C9A24A] text-[#0F1F2E] hover:bg-[#D8B45B] transition-colors flex items-center justify-center gap-2 shadow-sm"
            >
              <span>Run Pre-Commitment Check</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
