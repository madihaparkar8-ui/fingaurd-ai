package com.fingaurd.dto.response;

public class BehaviouralBiasDto {

    private String biasType;
    private String title;
    private String severity; // LOW, MODERATE, HIGH
    private String triggerEvidence;
    private String psychologicalMechanism;
    private String actionableCountermeasure;

    public BehaviouralBiasDto() {}

    public BehaviouralBiasDto(String biasType, String title, String severity,
                              String triggerEvidence, String psychologicalMechanism,
                              String actionableCountermeasure) {
        this.biasType = biasType;
        this.title = title;
        this.severity = severity;
        this.triggerEvidence = triggerEvidence;
        this.psychologicalMechanism = psychologicalMechanism;
        this.actionableCountermeasure = actionableCountermeasure;
    }

    public String getBiasType() {
        return biasType;
    }

    public void setBiasType(String biasType) {
        this.biasType = biasType;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSeverity() {
        return severity;
    }

    public void setSeverity(String severity) {
        this.severity = severity;
    }

    public String getTriggerEvidence() {
        return triggerEvidence;
    }

    public void setTriggerEvidence(String triggerEvidence) {
        this.triggerEvidence = triggerEvidence;
    }

    public String getPsychologicalMechanism() {
        return psychologicalMechanism;
    }

    public void setPsychologicalMechanism(String psychologicalMechanism) {
        this.psychologicalMechanism = psychologicalMechanism;
    }

    public String getActionableCountermeasure() {
        return actionableCountermeasure;
    }

    public void setActionableCountermeasure(String actionableCountermeasure) {
        this.actionableCountermeasure = actionableCountermeasure;
    }
}
