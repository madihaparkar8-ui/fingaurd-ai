package com.fingaurd.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "communications", indexes = {
    @Index(name = "idx_communication_user_id", columnList = "user_id"),
    @Index(name = "idx_communication_timestamp", columnList = "timestamp")
})
public class Communication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "communication_id")
    private Long communicationId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    @JsonIgnore
    private User user;

    @Lob
    @Column(name = "text", columnDefinition = "TEXT", nullable = false)
    private String text;

    @Column(name = "timestamp", nullable = false)
    private LocalDateTime timestamp;

    @Lob
    @Column(name = "influence_signals", columnDefinition = "TEXT")
    private String influenceSignals; // JSON detected signals

    public Communication() {
    }

    public Communication(User user, String text, LocalDateTime timestamp, String influenceSignals) {
        this.user = user;
        this.text = text;
        this.timestamp = timestamp != null ? timestamp : LocalDateTime.now();
        this.influenceSignals = influenceSignals;
    }

    @PrePersist
    protected void onCreate() {
        if (timestamp == null) {
            timestamp = LocalDateTime.now();
        }
    }

    public Long getCommunicationId() {
        return communicationId;
    }

    public void setCommunicationId(Long communicationId) {
        this.communicationId = communicationId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Long getUserId() {
        return user != null ? user.getUserId() : null;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public String getInfluenceSignals() {
        return influenceSignals;
    }

    public void setInfluenceSignals(String influenceSignals) {
        this.influenceSignals = influenceSignals;
    }
}
