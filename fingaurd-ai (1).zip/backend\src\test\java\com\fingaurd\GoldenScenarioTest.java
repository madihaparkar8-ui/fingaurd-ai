package com.fingaurd;

import com.fingaurd.dto.response.AnomalyEnsembleDto;
import com.fingaurd.dto.response.ComponentScoresDto;
import com.fingaurd.dto.response.InfluenceAnalysisResponse;
import com.fingaurd.model.Investment;
import com.fingaurd.model.InvestmentStatus;
import com.fingaurd.service.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class GoldenScenarioTest {

    private JourneyFeatureService featureService;
    private DeviationAnomalyDetector anomalyDetector;
    private InfluenceNlpService nlpService;
    private RiskFusionEngine riskFusionEngine;

    @BeforeEach
    void setUp() {
        SequenceRuleService sequenceRuleService = new SequenceRuleService();
        featureService = new JourneyFeatureService(sequenceRuleService);
        anomalyDetector = new DeviationAnomalyDetector();
        ReflectionTestUtils.setField(anomalyDetector, "zWeight", 0.4);
        ReflectionTestUtils.setField(anomalyDetector, "stepWeight", 0.3);
        ReflectionTestUtils.setField(anomalyDetector, "maxRatioWeight", 0.3);
        ReflectionTestUtils.setField(anomalyDetector, "zCutoff", 2.0);
        ReflectionTestUtils.setField(anomalyDetector, "zSpan", 3.0);
        ReflectionTestUtils.setField(anomalyDetector, "stepCutoff", 2.0);
        ReflectionTestUtils.setField(anomalyDetector, "stepSpan", 3.0);
        ReflectionTestUtils.setField(anomalyDetector, "maxRatioCutoff", 1.5);
        ReflectionTestUtils.setField(anomalyDetector, "maxRatioSpan", 3.5);

        nlpService = new InfluenceNlpService();

        riskFusionEngine = new RiskFusionEngine();
        ReflectionTestUtils.setField(riskFusionEngine, "escalationMax", 30.0);
        ReflectionTestUtils.setField(riskFusionEngine, "baselineMax", 25.0);
        ReflectionTestUtils.setField(riskFusionEngine, "velocityMax", 20.0);
        ReflectionTestUtils.setField(riskFusionEngine, "influenceMax", 25.0);
        ReflectionTestUtils.setField(riskFusionEngine, "escalationNudge", 5.0);
        ReflectionTestUtils.setField(riskFusionEngine, "velocityNormalizer", 0.7);
    }

    @Test
    @DisplayName("Golden Scenario: ₹20k -> (return) -> ₹30k -> ₹50k -> ₹100k -> proposed ₹400k produces 73 / HIGH with comm enabled, no indicators")
    void testGoldenScenario_CommunicationEnabledNoIndicators() {
        LocalDate d1 = LocalDate.of(2026, 9, 1);
        LocalDate d2 = LocalDate.of(2026, 9, 10);
        LocalDate d3 = LocalDate.of(2026, 9, 20);
        LocalDate d4 = LocalDate.of(2026, 9, 30);
        LocalDate proposedDate = LocalDate.of(2026, 10, 1);

        List<Investment> history = List.of(
                new Investment(null, "Apex Wealth Advisory", new BigDecimal("20000.00"), d1, "EQUITY", new BigDecimal("24000.00"), InvestmentStatus.RETURNED),
                new Investment(null, "Apex Wealth Advisory", new BigDecimal("30000.00"), d2, "EQUITY", null, InvestmentStatus.ACTIVE),
                new Investment(null, "Apex Wealth Advisory", new BigDecimal("50000.00"), d3, "EQUITY", null, InvestmentStatus.ACTIVE),
                new Investment(null, "Apex Wealth Advisory", new BigDecimal("100000.00"), d4, "EQUITY", null, InvestmentStatus.ACTIVE)
        );

        BigDecimal proposedAmount = new BigDecimal("400000.00");
        JourneyFeatures features = featureService.extractFeatures(history, proposedAmount, proposedDate, "Apex Wealth Advisory");

        // Assert baseline calculations
        assertEquals(50000.0, features.getBaselineMean().doubleValue(), 0.1);
        assertEquals(4.0, features.getHistoricalMaxRatio(), 0.01);
        assertTrue(features.getPopulationStdDev() > 30800 && features.getPopulationStdDev() < 30900);
        assertEquals(11.4, features.getBaselineZScore(), 0.2);
        assertTrue(features.isReturnFollowedByEscalation());

        // Velocity = (400000 - 20000) / 30 = 12666.67
        assertEquals(12666.67, features.getCommitmentVelocity(), 10.0);

        // Anomaly Ensemble
        AnomalyEnsembleDto anomaly = anomalyDetector.calculateAnomalyEnsemble(features);
        assertEquals(0.81, anomaly.getAnomalyScore(), 0.05);

        // Risk Fusion with communication enabled but no indicators found
        RiskFusionEngine.FusionResult result = riskFusionEngine.computeRisk(features, 0.0, true);

        ComponentScoresDto scores = result.getComponentScores();
        assertEquals(30.0, scores.getEscalationScore(), 0.1);
        assertEquals(25.0, scores.getBaselineDeviationScore(), 0.1);
        assertEquals(18.0, scores.getVelocityScore(), 0.5);
        assertEquals(0.0, scores.getInfluenceScore(), 0.1);

        assertEquals(73, result.getOverallScore());
        assertEquals("HIGH", result.getRiskLevel());
    }

    @Test
    @DisplayName("Golden Scenario: Redistribution when no communication is analyzed scores ≈ 97 (CRITICAL)")
    void testGoldenScenario_RedistributionWithoutCommunication() {
        LocalDate d1 = LocalDate.of(2026, 9, 1);
        LocalDate d2 = LocalDate.of(2026, 9, 10);
        LocalDate d3 = LocalDate.of(2026, 9, 20);
        LocalDate d4 = LocalDate.of(2026, 9, 30);
        LocalDate proposedDate = LocalDate.of(2026, 10, 1);

        List<Investment> history = List.of(
                new Investment(null, "Apex Wealth Advisory", new BigDecimal("20000.00"), d1, "EQUITY", new BigDecimal("24000.00"), InvestmentStatus.RETURNED),
                new Investment(null, "Apex Wealth Advisory", new BigDecimal("30000.00"), d2, "EQUITY", null, InvestmentStatus.ACTIVE),
                new Investment(null, "Apex Wealth Advisory", new BigDecimal("50000.00"), d3, "EQUITY", null, InvestmentStatus.ACTIVE),
                new Investment(null, "Apex Wealth Advisory", new BigDecimal("100000.00"), d4, "EQUITY", null, InvestmentStatus.ACTIVE)
        );

        JourneyFeatures features = featureService.extractFeatures(history, new BigDecimal("400000.00"), proposedDate, "Apex Wealth Advisory");
        RiskFusionEngine.FusionResult result = riskFusionEngine.computeRisk(features, 0.0, false);

        assertTrue(result.getComponentScores().getRedistributed());
        assertEquals(97, result.getOverallScore());
        assertEquals("CRITICAL", result.getRiskLevel());
    }

    @Test
    @DisplayName("Golden Scenario: Adding manipulative pressure text elevates score into CRITICAL")
    void testGoldenScenario_WithManipulativeText() {
        LocalDate d1 = LocalDate.of(2026, 9, 1);
        LocalDate proposedDate = LocalDate.of(2026, 10, 1);

        List<Investment> history = List.of(
                new Investment(null, "Apex Wealth Advisory", new BigDecimal("20000.00"), d1, "EQUITY", new BigDecimal("24000.00"), InvestmentStatus.RETURNED),
                new Investment(null, "Apex Wealth Advisory", new BigDecimal("30000.00"), d1.plusDays(10), "EQUITY", null, InvestmentStatus.ACTIVE),
                new Investment(null, "Apex Wealth Advisory", new BigDecimal("50000.00"), d1.plusDays(20), "EQUITY", null, InvestmentStatus.ACTIVE),
                new Investment(null, "Apex Wealth Advisory", new BigDecimal("100000.00"), d1.plusDays(29), "EQUITY", null, InvestmentStatus.ACTIVE)
        );

        String pressureText = "Exclusive VIP group closing in next 2 hours! Last chance today for guaranteed returns. Transfer ₹4,00,000 immediately to release your withdrawal!";
        InfluenceAnalysisResponse nlpResp = nlpService.analyse(pressureText, true);
        assertTrue(nlpResp.getIndicatorsDetected());
        assertTrue(nlpResp.getScoreContribution() > 18.0);

        JourneyFeatures features = featureService.extractFeatures(history, new BigDecimal("400000.00"), proposedDate, "Apex Wealth Advisory");
        RiskFusionEngine.FusionResult result = riskFusionEngine.computeRisk(features, nlpResp.getScoreContribution(), true);

        assertTrue(result.getOverallScore() >= 85);
        assertEquals("CRITICAL", result.getRiskLevel());
    }
}
