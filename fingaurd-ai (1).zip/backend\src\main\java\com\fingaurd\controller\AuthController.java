package com.fingaurd.controller;

import com.fingaurd.dto.request.LoginRequest;
import com.fingaurd.dto.request.RegisterRequest;
import com.fingaurd.dto.response.AuthResponse;
import com.fingaurd.dto.response.UserResponse;
import com.fingaurd.model.User;
import com.fingaurd.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/api/auth/register")
    public ResponseEntity<AuthResponse> register(@Valid @RequestBody RegisterRequest req) {
        AuthResponse resp = userService.register(req);
        return ResponseEntity.ok(resp);
    }

    @PostMapping("/api/auth/login")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody LoginRequest req) {
        AuthResponse resp = userService.authenticate(req);
        return ResponseEntity.ok(resp);
    }

    @GetMapping("/api/auth/me")
    public ResponseEntity<UserResponse> getCurrentUser(@AuthenticationPrincipal UserDetails userDetails) {
        if (userDetails == null) {
            return ResponseEntity.status(401).build();
        }
        UserResponse resp = userService.getUserProfile(userDetails.getUsername());
        return ResponseEntity.ok(resp);
    }

    @PostMapping("/api/users")
    public ResponseEntity<AuthResponse> createDemoUser(@Valid @RequestBody RegisterRequest req) {
        AuthResponse resp = userService.register(req);
        return ResponseEntity.ok(resp);
    }
}
