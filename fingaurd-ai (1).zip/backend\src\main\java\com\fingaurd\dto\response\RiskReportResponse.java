package com.fingaurd.dto.response;

import com.fingaurd.config.SafetyLanguage;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class RiskReportResponse {

    private Long reportId;
    private Long journeyId;
    private BigDecimal targetInvestment;
    private String targetEntity;
    private String componentScores;
    private Double anomalyScore;
    private Integer overallScore;
    private String riskLevel;
    private Boolean communicationUsed;
    private LocalDateTime createdAt;
    private String disclaimer = SafetyLanguage.DISCLAIMER;

    private ComponentScoresDto componentScoresDetail;
    private AnomalyEnsembleDto anomalyEnsemble;
    private List<RiskSignalDto> signals = new ArrayList<>();
    private List<BehaviouralBiasDto> behaviouralBiases = new ArrayList<>();
    private RiskSignalGroupResponse groupedSignals;

    public RiskReportResponse() {}

    public Long getReportId() {
        return reportId;
    }

    public void setReportId(Long reportId) {
        this.reportId = reportId;
    }

    public Long getJourneyId() {
        return journeyId;
    }

    public void setJourneyId(Long journeyId) {
        this.journeyId = journeyId;
    }

    public BigDecimal getTargetInvestment() {
        return targetInvestment;
    }

    public void setTargetInvestment(BigDecimal targetInvestment) {
        this.targetInvestment = targetInvestment;
    }

    public String getTargetEntity() {
        return targetEntity;
    }

    public void setTargetEntity(String targetEntity) {
        this.targetEntity = targetEntity;
    }

    public String getComponentScores() {
        return componentScores;
    }

    public void setComponentScores(String componentScores) {
        this.componentScores = componentScores;
    }

    public Double getAnomalyScore() {
        return anomalyScore;
    }

    public void setAnomalyScore(Double anomalyScore) {
        this.anomalyScore = anomalyScore;
    }

    public Integer getOverallScore() {
        return overallScore;
    }

    public void setOverallScore(Integer overallScore) {
        this.overallScore = overallScore;
    }

    public String getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(String riskLevel) {
        this.riskLevel = riskLevel;
    }

    public Boolean getCommunicationUsed() {
        return communicationUsed;
    }

    public void setCommunicationUsed(Boolean communicationUsed) {
        this.communicationUsed = communicationUsed;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public String getDisclaimer() {
        return disclaimer;
    }

    public void setDisclaimer(String disclaimer) {
        this.disclaimer = disclaimer;
    }

    public ComponentScoresDto getComponentScoresDetail() {
        return componentScoresDetail;
    }

    public void setComponentScoresDetail(ComponentScoresDto componentScoresDetail) {
        this.componentScoresDetail = componentScoresDetail;
    }

    public AnomalyEnsembleDto getAnomalyEnsemble() {
        return anomalyEnsemble;
    }

    public void setAnomalyEnsemble(AnomalyEnsembleDto anomalyEnsemble) {
        this.anomalyEnsemble = anomalyEnsemble;
    }

    public List<RiskSignalDto> getSignals() {
        return signals;
    }

    public void setSignals(List<RiskSignalDto> signals) {
        this.signals = signals;
    }

    public List<BehaviouralBiasDto> getBehaviouralBiases() {
        return behaviouralBiases;
    }

    public void setBehaviouralBiases(List<BehaviouralBiasDto> behaviouralBiases) {
        this.behaviouralBiases = behaviouralBiases;
    }

    public RiskSignalGroupResponse getGroupedSignals() {
        return groupedSignals;
    }

    public void setGroupedSignals(RiskSignalGroupResponse groupedSignals) {
        this.groupedSignals = groupedSignals;
    }
}

