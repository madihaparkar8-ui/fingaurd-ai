package com.fingaurd.dto.response;

import com.fingaurd.model.RiskSignal;

public class RiskSignalDto {

    private Long signalId;
    private String type;
    private String value;
    private String explanation;
    private Long sourceEvent;
    private String category; // what_changed, why_it_matters, verify

    public RiskSignalDto() {}

    public RiskSignalDto(Long signalId, String type, String value, String explanation, Long sourceEvent, String category) {
        this.signalId = signalId;
        this.type = type;
        this.value = value;
        this.explanation = explanation;
        this.sourceEvent = sourceEvent;
        this.category = category;
    }

    public static RiskSignalDto fromEntity(RiskSignal s, String category) {
        if (s == null) return null;
        return new RiskSignalDto(s.getSignalId(), s.getType(), s.getValue(), s.getExplanation(), s.getSourceEvent(), category);
    }

    public Long getSignalId() {
        return signalId;
    }

    public void setSignalId(Long signalId) {
        this.signalId = signalId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getExplanation() {
        return explanation;
    }

    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }

    public Long getSourceEvent() {
        return sourceEvent;
    }

    public void setSourceEvent(Long sourceEvent) {
        this.sourceEvent = sourceEvent;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
