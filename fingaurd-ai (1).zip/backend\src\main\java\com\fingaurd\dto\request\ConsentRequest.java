package com.fingaurd.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class ConsentRequest {

    @NotBlank(message = "Purpose is required")
    private String purpose = "COMMUNICATION_ANALYSIS";

    @NotNull(message = "Granted flag is required")
    private Boolean granted;

    public ConsentRequest() {}

    public ConsentRequest(String purpose, Boolean granted) {
        this.purpose = purpose;
        this.granted = granted;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public Boolean getGranted() {
        return granted;
    }

    public void setGranted(Boolean granted) {
        this.granted = granted;
    }
}
