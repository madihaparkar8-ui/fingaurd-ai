package com.fingaurd.dto.response;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class JourneyResponse {

    private Long journeyId;
    private Long userId;
    private LocalDate startDate;
    private LocalDate endDate;
    private Integer eventCount;
    private BigDecimal totalExposure;
    private BigDecimal maxSingleCommitment;
    private BigDecimal mean;
    private Double standardDeviation;
    private Long durationDays;
    private List<JourneyEventResponse> events = new ArrayList<>();

    public JourneyResponse() {}

    public Long getJourneyId() {
        return journeyId;
    }

    public void setJourneyId(Long journeyId) {
        this.journeyId = journeyId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public Integer getEventCount() {
        return eventCount;
    }

    public void setEventCount(Integer eventCount) {
        this.eventCount = eventCount;
    }

    public BigDecimal getTotalExposure() {
        return totalExposure;
    }

    public void setTotalExposure(BigDecimal totalExposure) {
        this.totalExposure = totalExposure;
    }

    public BigDecimal getMaxSingleCommitment() {
        return maxSingleCommitment;
    }

    public void setMaxSingleCommitment(BigDecimal maxSingleCommitment) {
        this.maxSingleCommitment = maxSingleCommitment;
    }

    public BigDecimal getMean() {
        return mean;
    }

    public void setMean(BigDecimal mean) {
        this.mean = mean;
    }

    public Double getStandardDeviation() {
        return standardDeviation;
    }

    public void setStandardDeviation(Double standardDeviation) {
        this.standardDeviation = standardDeviation;
    }

    public Long getDurationDays() {
        return durationDays;
    }

    public void setDurationDays(Long durationDays) {
        this.durationDays = durationDays;
    }

    public List<JourneyEventResponse> getEvents() {
        return events;
    }

    public void setEvents(List<JourneyEventResponse> events) {
        this.events = events;
    }
}
