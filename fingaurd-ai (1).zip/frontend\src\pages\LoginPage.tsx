import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Logo } from '../components/Logo';
import { Sparkles, ArrowRight, ShieldCheck, AlertCircle } from 'lucide-react';

export const LoginPage: React.FC = () => {
  const { login, loginAsDemo } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [demoLoading, setDemoLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      await login(email, password);
      navigate('/dashboard');
    } catch (err: any) {
      setError(err?.response?.data?.message || 'Invalid email or password. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleDemoLogin = async () => {
    setError(null);
    setDemoLoading(true);
    try {
      await loginAsDemo();
      navigate('/dashboard');
    } catch (err: any) {
      setError(err?.response?.data?.message || 'Demo login failed.');
    } finally {
      setDemoLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F6F3] flex flex-col justify-center py-12 px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <Link to="/" className="inline-block mb-6">
          <Logo size="lg" showTagline={true} />
        </Link>
        <h2 className="text-2xl font-heading font-extrabold text-[#0F1F2E]">
          Sign in to your account
        </h2>
        <p className="mt-1 text-xs text-[#5B6B7A]">
          Access pre-commitment intelligence and risk history
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-6 sm:px-10 shadow-fin-card rounded-fin border border-[#E4E8E4] space-y-6">
          {/* One-Click Demo Access Banner */}
          <div className="p-4 rounded-xl bg-[#E3F0EE] border border-[#BCE1DB] flex flex-col gap-2">
            <div className="flex items-center gap-2 text-xs font-bold text-[#1F5F5B]">
              <Sparkles className="w-4 h-4 text-[#C9A24A]" />
              Presentation Ready Demo Mode
            </div>
            <p className="text-[11px] text-[#5B6B7A]">
              Evaluate with pre-loaded Trust-to-Commitment Golden Scenario data.
            </p>
            <button
              type="button"
              onClick={handleDemoLogin}
              disabled={demoLoading}
              className="w-full mt-1 py-2 px-3 rounded-lg text-xs font-bold bg-[#1F5F5B] text-white hover:bg-[#2A7A74] transition-all flex items-center justify-center gap-1.5 shadow-2xs"
            >
              <span>{demoLoading ? 'Authenticating Demo...' : 'Use Demo Account (One Click)'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-[#E4E8E4]" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-white px-3 text-[#5B6B7A] font-semibold text-[10px]">Or sign in with email</span>
            </div>
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-[#0F1F2E] mb-1">
                Email address
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-[#E4E8E4] focus:outline-none focus:border-[#1F5F5B] focus:ring-1 focus:ring-[#1F5F5B] bg-white text-[#0F1F2E]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#0F1F2E] mb-1">
                Password
              </label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-[#E4E8E4] focus:outline-none focus:border-[#1F5F5B] focus:ring-1 focus:ring-[#1F5F5B] bg-white text-[#0F1F2E]"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 px-4 rounded-xl text-xs font-bold text-white bg-[#0F1F2E] hover:bg-[#1E2D3D] transition-colors shadow-2xs"
            >
              {loading ? 'Verifying Credentials...' : 'Sign In'}
            </button>
          </form>

          <div className="text-center text-xs text-[#5B6B7A]">
            Don't have an account yet?{' '}
            <Link to="/register" className="font-semibold text-[#1F5F5B] hover:underline">
              Create one now
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
