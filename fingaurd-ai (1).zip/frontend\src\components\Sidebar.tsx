import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  Coins,
  Milestone,
  ShieldAlert,
  FileCheck2,
  MessageSquareWarning,
  ShieldCheck,
  Info,
} from 'lucide-react';

const navItems = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/investments', label: 'Investments', icon: Coins },
  { to: '/journey', label: 'Journey Replay', icon: Milestone },
  { to: '/analyse', label: 'Risk Analysis', icon: ShieldAlert },
  { to: '/reports', label: 'Risk Reports', icon: FileCheck2 },
  { to: '/influence', label: 'Influence NLP', icon: MessageSquareWarning },
  { to: '/privacy', label: 'Privacy & Audit', icon: ShieldCheck },
  { to: '/about', label: 'Responsible AI', icon: Info },
];

export const Sidebar: React.FC = () => {
  return (
    <>
      {/* Desktop Left Sidebar */}
      <aside className="hidden lg:flex flex-col w-64 bg-white border-r border-[#E4E8E4] min-h-[calc(100vh-65px)] p-4">
        <div className="space-y-1.5 flex-1">
          <div className="px-3 pb-2 text-[10px] font-bold text-[#5B6B7A] uppercase tracking-wider">
            Risk Intelligence Platform
          </div>
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-[#E3F0EE] text-[#1F5F5B] shadow-2xs font-bold'
                      : 'text-[#5B6B7A] hover:text-[#0F1F2E] hover:bg-gray-50'
                  }`
                }
              >
                <Icon className="w-4 h-4 flex-shrink-0" />
                <span>{item.label}</span>
              </NavLink>
            );
          })}
        </div>

        {/* Prototype Assurance Footnote */}
        <div className="mt-auto p-3 bg-[#F5F6F3] rounded-xl border border-[#E4E8E4] text-[11px] text-[#5B6B7A]">
          <div className="font-semibold text-[#0F1F2E] mb-0.5">Pre-Commitment AI</div>
          Safe behavioural heuristics. Never bank or UPI linked.
        </div>
      </aside>

      {/* Mobile Bottom Tab Bar */}
      <nav className="lg:hidden fixed bottom-0 inset-x-0 bg-white border-t border-[#E4E8E4] z-40 px-2 py-1.5 flex items-center justify-around">
        {navItems.slice(0, 5).map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `flex flex-col items-center gap-0.5 p-1 rounded-lg text-[10px] font-medium transition-colors ${
                  isActive ? 'text-[#1F5F5B] font-bold' : 'text-[#5B6B7A]'
                }`
              }
            >
              <Icon className="w-4 h-4" />
              <span>{item.label}</span>
            </NavLink>
          );
        })}
      </nav>
    </>
  );
};

export default Sidebar;
