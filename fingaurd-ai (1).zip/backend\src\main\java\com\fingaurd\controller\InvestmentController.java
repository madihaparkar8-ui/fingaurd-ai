package com.fingaurd.controller;

import com.fingaurd.dto.request.InvestmentRequest;
import com.fingaurd.dto.response.CsvImportResultResponse;
import com.fingaurd.model.Investment;
import com.fingaurd.model.User;
import com.fingaurd.service.InvestmentService;
import com.fingaurd.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/investments")
public class InvestmentController {

    private final InvestmentService investmentService;
    private final UserService userService;

    public InvestmentController(InvestmentService investmentService, UserService userService) {
        this.investmentService = investmentService;
        this.userService = userService;
    }

    @GetMapping
    public ResponseEntity<List<Investment>> getInvestments(@AuthenticationPrincipal UserDetails userDetails) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        List<Investment> list = investmentService.getUserInvestments(user.getUserId());
        return ResponseEntity.ok(list);
    }

    @PostMapping
    public ResponseEntity<Investment> addInvestment(@AuthenticationPrincipal UserDetails userDetails,
                                                    @Valid @RequestBody InvestmentRequest req) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        Investment inv = investmentService.createInvestment(user, req);
        return ResponseEntity.ok(inv);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Investment> editInvestment(@AuthenticationPrincipal UserDetails userDetails,
                                                     @PathVariable Long id,
                                                     @Valid @RequestBody InvestmentRequest req) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        Investment inv = investmentService.updateInvestment(user, id, req);
        return ResponseEntity.ok(inv);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteInvestment(@AuthenticationPrincipal UserDetails userDetails,
                                                 @PathVariable Long id) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        investmentService.deleteInvestment(user, id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/import")
    public ResponseEntity<CsvImportResultResponse> importCsv(@AuthenticationPrincipal UserDetails userDetails,
                                                             @RequestParam("file") MultipartFile file) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        CsvImportResultResponse result = investmentService.importCsv(user, file);
        return ResponseEntity.ok(result);
    }
}
