import React, { useEffect, useState } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import { riskService, journeyService } from '../services/api';
import { RiskReport, Journey } from '../types';
import { formatINR, getRiskBandDetails } from '../utils/formatters';
import { RiskGauge } from '../components/RiskGauge';
import {
  AlertTriangle, ShieldCheck, CheckCircle2,
  ExternalLink, ArrowLeft, Clock, PhoneCall,
  CheckSquare, Square
} from 'lucide-react';

export const PausePage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const reportIdParam = searchParams.get('id');

  const [report, setReport] = useState<RiskReport | null>(null);
  const [journey, setJourney] = useState<Journey | null>(null);
  const [loading, setLoading] = useState(true);

  // Independent verification checklist tracking
  const [checkedItems, setCheckedItems] = useState<{ [key: number]: boolean }>({
    1: false,
    2: false,
    3: false,
    4: false,
    5: false,
    6: false,
    7: false,
  });

  const [acknowledged, setAcknowledged] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        let repId = reportIdParam ? Number(reportIdParam) : null;
        if (!repId) {
          const history = await riskService.getHistory();
          if (history.length > 0) repId = history[0].reportId;
        }

        if (repId) {
          const [rData, jData] = await Promise.all([
            riskService.getReport(repId),
            journeyService.getMyJourney().catch(() => null),
          ]);
          setReport(rData);
          setJourney(jData);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [reportIdParam]);

  const toggleCheck = (idx: number) => {
    setCheckedItems((prev) => ({ ...prev, [idx]: !prev[idx] }));
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F5F6F3] flex items-center justify-center p-6 animate-pulse">
        <div className="h-96 bg-gray-200 rounded-2xl w-full max-w-2xl" />
      </div>
    );
  }

  const score = report ? report.overallScore : 73;
  const band = getRiskBandDetails(score);

  const verificationPoints = [
    {
      id: 1,
      title: 'Check SEBI Registration of Advisor or Entity',
      desc: 'Verify if the advisor/intermediary holds an active registration certificate on the official SEBI portal.',
      link: 'https://www.sebi.gov.in/sebiweb/other/OtherAction.do?doRecognised=yes',
      label: 'sebi.gov.in',
    },
    {
      id: 2,
      title: 'Verify MCA Company Master Data',
      desc: 'Confirm the company CIN, registered address, active directors, and paid-up capital on the Ministry of Corporate Affairs portal.',
      link: 'https://www.mca.gov.in/content/mca/global/en/home.html',
      label: 'mca.gov.in',
    },
    {
      id: 3,
      title: 'Cross-Check RBI Alert List (Unauthorised Forex & Platforms)',
      desc: 'Consult the Reserve Bank of India Sakshi alert list of prohibited entities and offshore trading platforms.',
      link: 'https://www.rbi.org.in',
      label: 'rbi.org.in',
    },
    {
      id: 4,
      title: 'Never Pay "Fees" or "Taxes" to Release Withdrawals',
      desc: 'Regulated financial market institutions never request upfront security deposits or clearance fees to disburse user balances.',
      link: null,
      label: 'Critical Security Rule',
    },
    {
      id: 5,
      title: 'Speak with an Independent Trusted Family Member or Advisor',
      desc: 'Explain the proposed capital commitment out loud to an uninvolved third party before authorization.',
      link: null,
      label: 'Psychological Buffer',
    },
    {
      id: 6,
      title: 'Enforce a 24-Hour Cooling Off Period',
      desc: 'Deliberately wait 24 hours. Genuine investments do not vanish overnight; artificial urgency is a recognized coercive tactic.',
      link: null,
      label: 'Cooling-Off Delay',
    },
    {
      id: 7,
      title: 'National Cyber Crime Helpline: Dial 1930',
      desc: 'If unverified payment demands persist, immediately lodge an alert with the Cyber Crime Reporting Portal.',
      link: 'https://cybercrime.gov.in',
      label: 'cybercrime.gov.in / 1930',
    },
  ];

  return (
    <div className="min-h-screen bg-[#0C1822] text-[#F5F6F3] py-8 px-4 sm:px-6 lg:px-8 flex flex-col items-center">
      <div className="max-w-3xl w-full space-y-8">
        {/* Navigation back */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => navigate(-1)}
            className="text-xs font-semibold text-gray-400 hover:text-white flex items-center gap-1.5 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Dashboard</span>
          </button>
          <span className="text-[11px] font-mono uppercase tracking-widest text-[#C9A24A]">
            Cognitive Pause Protocol
          </span>
        </div>

        {/* Calm Header Intervention Card */}
        <div className="bg-[#13222E] p-6 sm:p-8 rounded-fin border border-[#1E2D3D] text-center space-y-4">
          <div className="w-12 h-12 rounded-full bg-[#B4414B]/20 text-[#B4414B] flex items-center justify-center mx-auto border border-[#B4414B]/40">
            <AlertTriangle className="w-6 h-6" />
          </div>

          <div className="space-y-1">
            <h1 className="text-2xl sm:text-3xl font-heading font-black tracking-tight text-white">
              Pause Before You Commit
            </h1>
            <p className="text-xs sm:text-sm text-gray-300 max-w-xl mx-auto">
              Our pre-commitment model has flagged this proposed transfer of{' '}
              <strong className="text-white font-tabular">{report ? formatINR(report.targetInvestment) : 'this amount'}</strong> to{' '}
              <strong className="text-white">{report?.targetEntity || 'the recipient'}</strong> as an unusual high-risk behavioral escalation.
            </p>
          </div>

          <div className="py-2 flex justify-center">
            <div className="bg-[#0C1822] px-6 py-4 rounded-2xl border border-[#1E2D3D]">
              <RiskGauge score={score} size={240} animate={false} showDetails={true} />
            </div>
          </div>
        </div>

        {/* Mini Journey Replay */}
        {journey && journey.events.length > 0 && (
          <div className="bg-[#13222E] p-6 rounded-fin border border-[#1E2D3D] space-y-3">
            <h3 className="font-heading font-bold text-sm text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#C9A24A]" />
              Historical Escalation Pathway
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              {journey.events.slice(-4).map((ev, i) => (
                <div key={i} className="p-3 rounded-xl bg-[#0C1822] border border-[#1E2D3D] space-y-1">
                  <div className="text-[10px] text-gray-400">Step {i + 1}</div>
                  <div className="font-extrabold text-white font-tabular">{formatINR(ev.amount)}</div>
                  {ev.returnAmount && (
                    <div className="text-[10px] text-[#5FA37A]">Payout: {formatINR(ev.returnAmount)}</div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 7-Point Independent Verification Checklist */}
        <div className="bg-[#13222E] p-6 sm:p-8 rounded-fin border border-[#1E2D3D] space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-[#1E2D3D]">
            <div>
              <h3 className="font-heading font-extrabold text-base text-white">
                Independent Verification Checklist
              </h3>
              <p className="text-xs text-gray-400">
                Complete these non-negotiable checks before transferring any funds.
              </p>
            </div>
            <span className="text-xs font-mono font-bold text-[#C9A24A]">
              {Object.values(checkedItems).filter(Boolean).length} / 7 Verified
            </span>
          </div>

          <div className="space-y-3">
            {verificationPoints.map((item) => {
              const isDone = !!checkedItems[item.id];
              return (
                <div
                  key={item.id}
                  onClick={() => toggleCheck(item.id)}
                  className={`p-4 rounded-xl border transition-all cursor-pointer flex items-start gap-3.5 ${
                    isDone
                      ? 'bg-[#1F5F5B]/20 border-[#1F5F5B]'
                      : 'bg-[#0C1822] border-[#1E2D3D] hover:border-gray-600'
                  }`}
                >
                  <button type="button" className="mt-0.5 text-gray-400">
                    {isDone ? (
                      <CheckSquare className="w-5 h-5 text-[#5FA37A]" />
                    ) : (
                      <Square className="w-5 h-5" />
                    )}
                  </button>

                  <div className="flex-1 space-y-0.5">
                    <div className="flex items-center justify-between text-xs font-bold text-white">
                      <span>{item.title}</span>
                      {item.link ? (
                        <a
                          href={item.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="text-[11px] text-[#C9A24A] hover:underline flex items-center gap-1 font-normal"
                        >
                          {item.label} <ExternalLink className="w-3 h-3" />
                        </a>
                      ) : (
                        <span className="text-[10px] text-gray-400 font-mono">{item.label}</span>
                      )}
                    </div>
                    <p className="text-xs text-gray-400 leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Forced Acknowledgement & Conditional Action */}
        <div className="bg-[#13222E] p-6 rounded-fin border border-[#1E2D3D] space-y-4">
          <label className="flex items-start gap-3 cursor-pointer">
            <input
              type="checkbox"
              checked={acknowledged}
              onChange={(e) => setAcknowledged(e.target.checked)}
              className="mt-1 rounded text-[#1F5F5B] focus:ring-[#1F5F5B] accent-[#1F5F5B]"
            />
            <div className="text-xs text-gray-300 leading-relaxed">
              <strong className="text-white">Mandatory Safety Acknowledgement:</strong> I have reviewed the independent verification checklist. I acknowledge that this proposed commitment exhibits high-risk behavioural anomalies and that capital transferred to unverified advisors or private platforms cannot be recovered by Fingaurd AI.
            </div>
          </label>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-[#1E2D3D]">
            <button
              type="button"
              onClick={() => navigate('/dashboard')}
              className="w-full sm:w-auto px-6 py-3 rounded-xl text-xs font-bold bg-[#1F5F5B] text-white hover:bg-[#2A7A74] transition-all shadow-md"
            >
              Cancel Transfer & Return to Safety
            </button>

            <button
              type="button"
              disabled={!acknowledged}
              onClick={() => {
                alert('Commitment noted. Please exercise extreme caution and verify credentials.');
                navigate('/dashboard');
              }}
              className={`w-full sm:w-auto px-6 py-3 rounded-xl text-xs font-bold border transition-all ${
                acknowledged
                  ? 'bg-transparent border-[#B4414B] text-[#B4414B] hover:bg-[#B4414B]/10 cursor-pointer'
                  : 'opacity-30 border-gray-600 text-gray-500 cursor-not-allowed'
              }`}
            >
              Proceed Anyway (Under User Discretion)
            </button>
          </div>
        </div>

        <div className="text-center text-[11px] text-gray-500 pb-8">
          Prototype score — not validated. This is not financial advice and not a fraud verdict.
        </div>
      </div>
    </div>
  );
};

export default PausePage;
