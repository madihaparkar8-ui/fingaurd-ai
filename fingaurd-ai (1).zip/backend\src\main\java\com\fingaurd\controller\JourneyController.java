package com.fingaurd.controller;

import com.fingaurd.dto.response.JourneyResponse;
import com.fingaurd.exception.UnauthorizedException;
import com.fingaurd.model.Role;
import com.fingaurd.model.User;
import com.fingaurd.service.JourneyService;
import com.fingaurd.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class JourneyController {

    private final JourneyService journeyService;
    private final UserService userService;

    public JourneyController(JourneyService journeyService, UserService userService) {
        this.journeyService = journeyService;
        this.userService = userService;
    }

    @GetMapping("/{id}/journey")
    public ResponseEntity<JourneyResponse> getJourneyByUserId(@AuthenticationPrincipal UserDetails userDetails,
                                                              @PathVariable Long id) {
        User currentUser = userService.getUserByEmail(userDetails.getUsername());
        if (!currentUser.getUserId().equals(id) && currentUser.getRole() != Role.ADMIN) {
            throw new UnauthorizedException("Access denied: You can only view your own investment journey.");
        }

        JourneyResponse resp = journeyService.reconstructUserJourney(id);
        return ResponseEntity.ok(resp);
    }

    @GetMapping("/journey")
    public ResponseEntity<JourneyResponse> getMyJourney(@AuthenticationPrincipal UserDetails userDetails) {
        User currentUser = userService.getUserByEmail(userDetails.getUsername());
        JourneyResponse resp = journeyService.reconstructUserJourney(currentUser.getUserId());
        return ResponseEntity.ok(resp);
    }
}
