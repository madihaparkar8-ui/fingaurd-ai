package com.fingaurd.controller;

import com.fingaurd.dto.request.AnalyseRequest;
import com.fingaurd.dto.response.RiskReportResponse;
import com.fingaurd.dto.response.RiskSignalGroupResponse;
import com.fingaurd.model.User;
import com.fingaurd.service.RiskAnalysisService;
import com.fingaurd.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/risk")
public class RiskController {

    private final RiskAnalysisService riskAnalysisService;
    private final UserService userService;

    public RiskController(RiskAnalysisService riskAnalysisService, UserService userService) {
        this.riskAnalysisService = riskAnalysisService;
        this.userService = userService;
    }

    @PostMapping("/analyse")
    public ResponseEntity<RiskReportResponse> analyseCommitment(@AuthenticationPrincipal UserDetails userDetails,
                                                                @Valid @RequestBody AnalyseRequest req) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        RiskReportResponse report = riskAnalysisService.analyseProposedCommitment(user, req);
        return ResponseEntity.ok(report);
    }

    @GetMapping("/{reportId}")
    public ResponseEntity<RiskReportResponse> getReport(@AuthenticationPrincipal UserDetails userDetails,
                                                        @PathVariable Long reportId) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        RiskReportResponse report = riskAnalysisService.getReportById(user, reportId);
        return ResponseEntity.ok(report);
    }

    @GetMapping("/{reportId}/signals")
    public ResponseEntity<RiskSignalGroupResponse> getGroupedSignals(@AuthenticationPrincipal UserDetails userDetails,
                                                                     @PathVariable Long reportId) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        RiskSignalGroupResponse signals = riskAnalysisService.getSignalsByReportId(user, reportId);
        return ResponseEntity.ok(signals);
    }

    @GetMapping("/history")
    public ResponseEntity<List<RiskReportResponse>> getReportsHistory(@AuthenticationPrincipal UserDetails userDetails) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        List<RiskReportResponse> history = riskAnalysisService.getUserReportsHistory(user.getUserId());
        return ResponseEntity.ok(history);
    }
}
