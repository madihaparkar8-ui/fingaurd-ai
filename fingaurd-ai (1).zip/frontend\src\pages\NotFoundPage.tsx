import React from 'react';
import { Link } from 'react-router-dom';
import { Logo } from '../components/Logo';
import { ArrowLeft } from 'lucide-react';

export const NotFoundPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#F5F6F3] flex flex-col items-center justify-center p-6 text-center">
      <Logo size="lg" showTagline={false} className="mb-6" />
      <h1 className="text-6xl font-black font-heading text-[#0F1F2E] font-tabular">404</h1>
      <h2 className="text-xl font-bold font-heading text-[#0F1F2E] mt-2">Page Not Found</h2>
      <p className="text-xs text-[#5B6B7A] max-w-sm mt-1 mb-6">
        The requested screen does not exist or has moved. Return to the secure dashboard or landing page.
      </p>
      <Link
        to="/dashboard"
        className="px-5 py-2.5 rounded-xl text-xs font-bold bg-[#1F5F5B] text-white hover:bg-[#2A7A74] flex items-center gap-2 shadow-2xs"
      >
        <ArrowLeft className="w-4 h-4" />
        Return to Dashboard
      </Link>
    </div>
  );
};

export default NotFoundPage;
