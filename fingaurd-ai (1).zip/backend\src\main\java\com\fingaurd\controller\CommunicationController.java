package com.fingaurd.controller;

import com.fingaurd.dto.request.StandaloneInfluenceRequest;
import com.fingaurd.dto.response.InfluenceAnalysisResponse;
import com.fingaurd.exception.BadRequestException;
import com.fingaurd.model.ConsentRecord;
import com.fingaurd.model.User;
import com.fingaurd.repository.ConsentRecordRepository;
import com.fingaurd.service.InfluenceNlpService;
import com.fingaurd.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/communications")
public class CommunicationController {

    private final InfluenceNlpService influenceNlpService;
    private final UserService userService;
    private final ConsentRecordRepository consentRecordRepository;

    public CommunicationController(InfluenceNlpService influenceNlpService,
                                   UserService userService,
                                   ConsentRecordRepository consentRecordRepository) {
        this.influenceNlpService = influenceNlpService;
        this.userService = userService;
        this.consentRecordRepository = consentRecordRepository;
    }

    @PostMapping("/analyse")
    public ResponseEntity<InfluenceAnalysisResponse> analyseInfluence(@AuthenticationPrincipal UserDetails userDetails,
                                                                      @Valid @RequestBody StandaloneInfluenceRequest req) {
        if (!Boolean.TRUE.equals(req.getConsentGranted())) {
            throw new BadRequestException("Explicit user consent is mandatory for communication influence analysis.");
        }

        User user = userService.getUserByEmail(userDetails.getUsername());
        consentRecordRepository.save(new ConsentRecord(user.getUserId(), "COMMUNICATION_ANALYSIS", true, LocalDateTime.now()));

        InfluenceAnalysisResponse resp = influenceNlpService.analyse(req.getText(), true);
        return ResponseEntity.ok(resp);
    }
}
