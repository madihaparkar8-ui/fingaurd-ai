import React, { useEffect, useState } from 'react';
import { getRiskBandDetails } from '../utils/formatters';

interface RiskGaugeProps {
  score: number;
  size?: number;
  animate?: boolean;
  showDetails?: boolean;
}

export const RiskGauge: React.FC<RiskGaugeProps> = ({
  score,
  size = 280,
  animate = true,
  showDetails = true,
}) => {
  const [displayScore, setDisplayScore] = useState(animate ? 0 : score);
  const band = getRiskBandDetails(score);

  useEffect(() => {
    if (!animate) {
      setDisplayScore(score);
      return;
    }

    let start = 0;
    const duration = 1200;
    const frameRate = 1000 / 60;
    const totalFrames = Math.round(duration / frameRate);
    let frame = 0;

    const timer = setInterval(() => {
      frame++;
      const progress = frame / totalFrames;
      // easeOutCubic
      const ease = 1 - Math.pow(1 - progress, 3);
      const current = Math.min(score, Math.round(start + (score - start) * ease));
      setDisplayScore(current);

      if (frame >= totalFrames) {
        clearInterval(timer);
        setDisplayScore(score);
      }
    }, frameRate);

    return () => clearInterval(timer);
  }, [score, animate]);

  // Semi-circle SVG coordinates
  const radius = 100;
  const strokeWidth = 16;
  const cx = 140;
  const cy = 130;
  const circumference = Math.PI * radius; // Half-circle perimeter
  const strokeDashoffset = circumference - (displayScore / 100) * circumference;

  return (
    <div className="flex flex-col items-center justify-center">
      <div className="relative" style={{ width: size, height: size * 0.65 }}>
        <svg
          viewBox="0 0 280 160"
          className="w-full h-full overflow-visible"
        >
          {/* Background Arc */}
          <path
            d="M 40,130 A 100,100 0 0,1 240,130"
            fill="none"
            stroke="#E4E8E4"
            strokeWidth={strokeWidth}
            strokeLinecap="round"
          />

          {/* Active Band Colored Progress Arc */}
          <path
            d="M 40,130 A 100,100 0 0,1 240,130"
            fill="none"
            stroke={band.color}
            strokeWidth={strokeWidth}
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            className="transition-all duration-300 ease-out"
          />

          {/* Gauge Center Needle Indicator Point */}
          {(() => {
            const angle = Math.PI - (displayScore / 100) * Math.PI;
            const needleX = cx + (radius - 5) * Math.cos(angle);
            const needleY = cy - (radius - 5) * Math.sin(angle);
            return (
              <circle
                cx={needleX}
                cy={needleY}
                r="6"
                fill="#FFFFFF"
                stroke={band.color}
                strokeWidth="3"
                className="drop-shadow-md"
              />
            );
          })()}
        </svg>

        {/* Center Display Score and Band Chip */}
        <div className="absolute inset-x-0 bottom-2 flex flex-col items-center text-center">
          <span className="text-5xl font-extrabold font-heading tracking-tight text-[#0F1F2E] font-tabular">
            {displayScore}
          </span>
          <span className="text-xs uppercase font-medium tracking-wider text-[#5B6B7A] mt-0.5">
            Risk Index (0–100)
          </span>
        </div>
      </div>

      {showDetails && (
        <div className="mt-3 flex flex-col items-center gap-1.5">
          <span
            className="px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider transition-colors"
            style={{ backgroundColor: band.bgColor, color: band.color, border: `1px solid ${band.borderColor}` }}
          >
            {band.label}
          </span>
          <p className="text-xs text-[#5B6B7A] text-center max-w-[240px]">
            {band.description}
          </p>
        </div>
      )}
    </div>
  );
};

export default RiskGauge;
