package com.fingaurd.config;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SpaController {

    @GetMapping(value = {
            "/login",
            "/register",
            "/dashboard",
            "/investments",
            "/journey",
            "/analyse",
            "/reports",
            "/what-changed",
            "/pause",
            "/influence",
            "/privacy",
            "/about"
    })
    public String forwardSpaRoutes() {
        return "forward:/index.html";
    }
}
