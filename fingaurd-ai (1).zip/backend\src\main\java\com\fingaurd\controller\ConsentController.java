package com.fingaurd.controller;

import com.fingaurd.dto.request.ConsentRequest;
import com.fingaurd.model.ConsentRecord;
import com.fingaurd.model.User;
import com.fingaurd.repository.ConsentRecordRepository;
import com.fingaurd.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Optional;

@RestController
@RequestMapping("/api/consent")
public class ConsentController {

    private final ConsentRecordRepository consentRecordRepository;
    private final UserService userService;

    public ConsentController(ConsentRecordRepository consentRecordRepository, UserService userService) {
        this.consentRecordRepository = consentRecordRepository;
        this.userService = userService;
    }

    @GetMapping
    public ResponseEntity<ConsentRecord> getConsent(@AuthenticationPrincipal UserDetails userDetails,
                                                    @RequestParam(defaultValue = "COMMUNICATION_ANALYSIS") String purpose) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        Optional<ConsentRecord> consent = consentRecordRepository.findTopByUserIdAndPurposeOrderByTimestampDesc(user.getUserId(), purpose);
        return consent.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.ok(new ConsentRecord(user.getUserId(), purpose, false, LocalDateTime.now())));
    }

    @PostMapping
    public ResponseEntity<ConsentRecord> recordConsent(@AuthenticationPrincipal UserDetails userDetails,
                                                       @Valid @RequestBody ConsentRequest req) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        ConsentRecord record = new ConsentRecord(user.getUserId(), req.getPurpose(), req.getGranted(), LocalDateTime.now());
        record = consentRecordRepository.save(record);
        return ResponseEntity.ok(record);
    }
}
