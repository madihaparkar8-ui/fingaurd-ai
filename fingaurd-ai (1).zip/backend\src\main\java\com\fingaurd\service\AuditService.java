package com.fingaurd.service;

import com.fingaurd.model.AuditEvent;
import com.fingaurd.model.User;
import com.fingaurd.repository.AuditEventRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AuditService {

    private final AuditEventRepository auditEventRepository;

    public AuditService(AuditEventRepository auditEventRepository) {
        this.auditEventRepository = auditEventRepository;
    }

    @Transactional
    public void recordEvent(User user, String actor, String action, String resource, String result) {
        AuditEvent event = new AuditEvent(
                user,
                actor != null ? actor : (user != null ? user.getEmail() : "SYSTEM"),
                action,
                resource,
                LocalDateTime.now(),
                result
        );
        auditEventRepository.save(event);
    }

    @Transactional(readOnly = true)
    public List<AuditEvent> getUserAuditEvents(Long userId) {
        return auditEventRepository.findTop50ByUser_UserIdOrderByTimestampDesc(userId);
    }
}
