package com.fingaurd.dto.response;

import com.fingaurd.config.SafetyLanguage;
import java.util.ArrayList;
import java.util.List;

public class InfluenceAnalysisResponse {

    private String heading = "Manipulation indicators detected in communication";
    private String text;
    private Boolean indicatorsDetected = false;
    private Double highestConfidence = 0.0;
    private Double scoreContribution = 0.0; // 0 to 25
    private List<InfluenceCategoryDto> detectedCategories = new ArrayList<>();
    private String disclaimer = SafetyLanguage.DISCLAIMER;

    public InfluenceAnalysisResponse() {}

    public String getHeading() {
        return heading;
    }

    public void setHeading(String heading) {
        this.heading = heading;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Boolean getIndicatorsDetected() {
        return indicatorsDetected;
    }

    public void setIndicatorsDetected(Boolean indicatorsDetected) {
        this.indicatorsDetected = indicatorsDetected;
    }

    public Double getHighestConfidence() {
        return highestConfidence;
    }

    public void setHighestConfidence(Double highestConfidence) {
        this.highestConfidence = highestConfidence;
    }

    public Double getScoreContribution() {
        return scoreContribution;
    }

    public void setScoreContribution(Double scoreContribution) {
        this.scoreContribution = scoreContribution;
    }

    public List<InfluenceCategoryDto> getDetectedCategories() {
        return detectedCategories;
    }

    public void setDetectedCategories(List<InfluenceCategoryDto> detectedCategories) {
        this.detectedCategories = detectedCategories;
    }

    public String getDisclaimer() {
        return disclaimer;
    }

    public void setDisclaimer(String disclaimer) {
        this.disclaimer = disclaimer;
    }
}
