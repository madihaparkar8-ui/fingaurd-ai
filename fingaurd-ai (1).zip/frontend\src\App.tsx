import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import Layout from './components/Layout';

import LandingPage from './pages/LandingPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DashboardPage from './pages/DashboardPage';
import InvestmentsPage from './pages/InvestmentsPage';
import JourneyPage from './pages/JourneyPage';
import AnalysePage from './pages/AnalysePage';
import ReportPage from './pages/ReportPage';
import WhatChangedPage from './pages/WhatChangedPage';
import PausePage from './pages/PausePage';
import InfluencePage from './pages/InfluencePage';
import PrivacyAuditPage from './pages/PrivacyAuditPage';
import AboutPage from './pages/AboutPage';
import NotFoundPage from './pages/NotFoundPage';

export const App: React.FC = () => {
  return (
    <AuthProvider>
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/pause" element={<PausePage />} />

        {/* Protected Dashboard Routes */}
        <Route
          element={
            <ProtectedRoute>
              <Layout />
            </ProtectedRoute>
          }
        >
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/investments" element={<InvestmentsPage />} />
          <Route path="/journey" element={<JourneyPage />} />
          <Route path="/analyse" element={<AnalysePage />} />
          <Route path="/reports" element={<ReportPage />} />
          <Route path="/what-changed" element={<WhatChangedPage />} />
          <Route path="/influence" element={<InfluencePage />} />
          <Route path="/privacy" element={<PrivacyAuditPage />} />
          <Route path="/about" element={<AboutPage />} />
        </Route>

        {/* 404 Route */}
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </AuthProvider>
  );
};

export default App;
