import React from 'react';
import { Info, Scale, ShieldAlert, BookOpen, AlertOctagon } from 'lucide-react';

export const AboutPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <h1 className="text-2xl font-heading font-black tracking-tight text-[#0F1F2E] flex items-center gap-2">
          <Info className="w-6 h-6 text-[#1F5F5B]" />
          About & Responsible AI Architecture
        </h1>
        <p className="text-xs text-[#5B6B7A]">
          Academic specification, algorithmic methodology, and safety governance boundaries.
        </p>
      </div>

      {/* Prominent Mandatory Prototype Disclaimer */}
      <div className="p-5 rounded-2xl bg-[#FBF1DB] border border-[#F0D49C] text-[#D9A441] space-y-2">
        <div className="flex items-center gap-2 text-sm font-extrabold text-[#9A7228]">
          <AlertOctagon className="w-5 h-5 text-[#D9A441]" />
          <span>Mandatory Consumer-Safety Notice</span>
        </div>
        <p className="text-xs text-[#7A5A1E] leading-relaxed">
          <strong>Prototype score — not validated. This is not financial advice and not a fraud verdict.</strong>
          <br />
          Fingaurd AI is an academic prototype developed for a University Full Stack Java & AI/ML Mini Project. It does not replace SEBI-certified investment advisors, professional legal counsel, or official law enforcement investigations.
        </p>
      </div>

      {/* Algorithmic Scoring in Plain Language */}
      <div className="bg-white p-6 sm:p-8 rounded-fin border border-[#E4E8E4] shadow-fin-card space-y-6">
        <div>
          <h2 className="text-lg font-heading font-extrabold text-[#0F1F2E]">
            How the Scoring Engine Works
          </h2>
          <p className="text-xs text-[#5B6B7A]">
            The Investment Manipulation Risk Index (0–100) is an explainable weighted fusion of four distinct behavioral dimensions.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-[#F5F6F3] border border-[#E4E8E4] space-y-2">
            <h4 className="font-bold text-[#0F1F2E] text-sm">1. Financial Escalation (Max 30)</h4>
            <p className="text-[#5B6B7A] leading-relaxed">
              Measures how much larger the proposed commitment is relative to your historical maximum:
              <br />
              <code className="text-[11px] font-mono text-[#1F5F5B]">30 × clamp01((historicalMaxRatio - 1.0) / 3.0)</code>
              <br />
              Nudged upward by 5 points if a sudden 2× step jump or a return-followed-by-escalation sequence is triggered.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#F5F6F3] border border-[#E4E8E4] space-y-2">
            <h4 className="font-bold text-[#0F1F2E] text-sm">2. Personal Baseline Deviation (Max 25)</h4>
            <p className="text-[#5B6B7A] leading-relaxed">
              Calculates how many standard deviations ($z$-score) the proposed amount sits away from your historical mean ($\mu$):
              <br />
              <code className="text-[11px] font-mono text-[#1F5F5B]">25 × clamp01(|z| / 3.0)</code>
              <br />
              Safe fallback prevents division-by-zero when historical variance is zero.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#F5F6F3] border border-[#E4E8E4] space-y-2">
            <h4 className="font-bold text-[#0F1F2E] text-sm">3. Commitment Velocity (Max 20)</h4>
            <p className="text-[#5B6B7A] leading-relaxed">
              Quantifies capital acceleration in ₹/day across the entire journey duration:
              <br />
              <code className="text-[11px] font-mono text-[#1F5F5B]">20 × clamp01((velocity / firstAmount) / 0.7)</code>
              <br />
              Identifies rapid accumulation windows commonly seen in grooming frauds.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#F5F6F3] border border-[#E4E8E4] space-y-2">
            <h4 className="font-bold text-[#0F1F2E] text-sm">4. Influence & Persuasion NLP (Max 25)</h4>
            <p className="text-[#5B6B7A] leading-relaxed">
              Evaluates opt-in communication against 7 coercive persuasion categories (urgency, guaranteed returns, withdrawal fees, VIP groups, SEBI guru claims).
              <br />
              <strong>Weight Redistribution:</strong> If communication is omitted or unconsented, the other 3 dimensions are scaled by $100 / 75$ to preserve an identical 0–100 scale.
            </p>
          </div>
        </div>

        {/* Risk Bands Specification */}
        <div className="pt-4 border-t border-[#E4E8E4] space-y-3">
          <h3 className="font-heading font-extrabold text-sm text-[#0F1F2E]">
            Standardized Risk Bands
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center text-xs">
            <div className="p-3 rounded-xl bg-[#E6F2EA] text-[#5FA37A] border border-[#A4D1B5] font-bold">
              0 – 25 : LOW
            </div>
            <div className="p-3 rounded-xl bg-[#FBF1DB] text-[#D9A441] border border-[#F0D49C] font-bold">
              26 – 50 : MODERATE
            </div>
            <div className="p-3 rounded-xl bg-[#FBE9E0] text-[#D9784A] border border-[#F0BC9F] font-bold">
              51 – 75 : HIGH
            </div>
            <div className="p-3 rounded-xl bg-[#F6E2E4] text-[#B4414B] border border-[#E29DA3] font-bold">
              76 – 100 : CRITICAL
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;
