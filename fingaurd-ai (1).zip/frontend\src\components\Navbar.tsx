import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Logo } from './Logo';
import { demoService } from '../services/api';
import { ShieldAlert, LogOut, User as UserIcon, Sparkles, ChevronDown } from 'lucide-react';

export const Navbar: React.FC = () => {
  const { user, logout, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [presetLoading, setPresetLoading] = useState(false);

  const handleSeed = async (preset: string) => {
    try {
      setPresetLoading(true);
      await demoService.seed(preset);
      window.location.reload();
    } catch (e) {
      console.error(e);
    } finally {
      setPresetLoading(false);
    }
  };

  return (
    <header className="sticky top-0 z-30 bg-[#F5F6F3]/80 backdrop-blur-md border-b border-[#E4E8E4] px-4 lg:px-8 py-3.5 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link to={isAuthenticated ? "/dashboard" : "/"} className="hover:opacity-95 transition-opacity">
          <Logo size="md" showTagline={false} />
        </Link>

        <div className="flex items-center gap-3">
          {isAuthenticated ? (
            <>
              {/* Quick Pre-Commitment Action Button */}
              <Link
                to="/analyse"
                className="hidden sm:inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold bg-[#1F5F5B] text-white hover:bg-[#2A7A74] transition-all shadow-sm"
              >
                <ShieldAlert className="w-3.5 h-3.5" />
                Pre-Commitment Check
              </Link>

              {/* Demo Journey Quick-Switcher */}
              <div className="relative">
                <button
                  onClick={() => setDropdownOpen(!dropdownOpen)}
                  disabled={presetLoading}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#E4E8E4] bg-white text-xs font-medium text-[#0F1F2E] hover:bg-gray-50 transition-colors shadow-2xs"
                >
                  <Sparkles className="w-3.5 h-3.5 text-[#C9A24A]" />
                  <span className="hidden md:inline">Demo Journeys</span>
                  <ChevronDown className="w-3 h-3 text-[#5B6B7A]" />
                </button>

                {dropdownOpen && (
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-lg border border-[#E4E8E4] py-1 z-50 animate-in fade-in slide-in-from-top-1">
                    <div className="px-3 py-1.5 text-[11px] font-semibold text-[#5B6B7A] uppercase tracking-wider border-b border-gray-100">
                      Switch Scenario Preset
                    </div>
                    <button
                      onClick={() => { handleSeed('TRUST_TO_COMMITMENT'); setDropdownOpen(false); }}
                      className="w-full text-left px-3 py-2 text-xs text-[#0F1F2E] hover:bg-[#E3F0EE] hover:text-[#1F5F5B] transition-colors flex flex-col"
                    >
                      <span className="font-semibold">Trust-to-Commitment (Golden)</span>
                      <span className="text-[10px] text-gray-500">₹20k → Return → ₹30k → ₹50k → ₹100k → ₹400k</span>
                    </button>
                    <button
                      onClick={() => { handleSeed('NORMAL'); setDropdownOpen(false); }}
                      className="w-full text-left px-3 py-2 text-xs text-[#0F1F2E] hover:bg-[#E3F0EE] hover:text-[#1F5F5B] transition-colors flex flex-col"
                    >
                      <span className="font-semibold">Normal Portfolio</span>
                      <span className="text-[10px] text-gray-500">Balanced recurring index investments</span>
                    </button>
                    <button
                      onClick={() => { handleSeed('GRADUAL'); setDropdownOpen(false); }}
                      className="w-full text-left px-3 py-2 text-xs text-[#0F1F2E] hover:bg-[#E3F0EE] hover:text-[#1F5F5B] transition-colors flex flex-col"
                    >
                      <span className="font-semibold">Gradual Escalation</span>
                      <span className="text-[10px] text-gray-500">₹10k → ₹20k → ₹40k → ₹80k</span>
                    </button>
                    <button
                      onClick={() => { handleSeed('SUDDEN'); setDropdownOpen(false); }}
                      className="w-full text-left px-3 py-2 text-xs text-[#0F1F2E] hover:bg-[#E3F0EE] hover:text-[#1F5F5B] transition-colors flex flex-col"
                    >
                      <span className="font-semibold">Sudden Jump</span>
                      <span className="text-[10px] text-gray-500">Small baseline, sudden outsized jump</span>
                    </button>
                    <button
                      onClick={() => { handleSeed('REPEATED_ENTITY'); setDropdownOpen(false); }}
                      className="w-full text-left px-3 py-2 text-xs text-[#0F1F2E] hover:bg-[#E3F0EE] hover:text-[#1F5F5B] transition-colors flex flex-col"
                    >
                      <span className="font-semibold">Repeated-Entity Trap</span>
                      <span className="text-[10px] text-gray-500">Concentrated capital to unverified entity</span>
                    </button>
                  </div>
                )}
              </div>

              {/* User Avatar & Logout */}
              <div className="flex items-center gap-2 pl-2 border-l border-[#E4E8E4]">
                <div className="w-8 h-8 rounded-full bg-[#E3F0EE] text-[#1F5F5B] flex items-center justify-center font-bold text-xs">
                  {user?.name ? user.name.charAt(0).toUpperCase() : <UserIcon className="w-4 h-4" />}
                </div>
                <button
                  onClick={() => { logout(); navigate('/'); }}
                  title="Log out"
                  className="p-1.5 text-[#5B6B7A] hover:text-red-600 transition-colors rounded-lg hover:bg-gray-100"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            </>
          ) : (
            <div className="flex items-center gap-2">
              <Link
                to="/login"
                className="px-4 py-2 text-xs font-semibold text-[#0F1F2E] hover:text-[#1F5F5B] transition-colors"
              >
                Log In
              </Link>
              <Link
                to="/register"
                className="px-4 py-2 rounded-lg text-xs font-semibold bg-[#1F5F5B] text-white hover:bg-[#2A7A74] transition-all shadow-xs"
              >
                Get Started
              </Link>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Navbar;
