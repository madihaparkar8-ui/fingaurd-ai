package com.fingaurd.repository;

import com.fingaurd.model.RiskSignal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface RiskSignalRepository extends JpaRepository<RiskSignal, Long> {
    List<RiskSignal> findByRiskReport_ReportId(Long reportId);
}
