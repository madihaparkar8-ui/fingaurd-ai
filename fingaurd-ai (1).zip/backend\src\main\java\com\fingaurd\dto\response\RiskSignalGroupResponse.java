package com.fingaurd.dto.response;

import java.util.ArrayList;
import java.util.List;

public class RiskSignalGroupResponse {

    private List<RiskSignalDto> whatChanged = new ArrayList<>();
    private List<RiskSignalDto> whyItMatters = new ArrayList<>();
    private List<RiskSignalDto> whatCanIVerify = new ArrayList<>();

    public RiskSignalGroupResponse() {}

    public RiskSignalGroupResponse(List<RiskSignalDto> whatChanged, List<RiskSignalDto> whyItMatters, List<RiskSignalDto> whatCanIVerify) {
        this.whatChanged = whatChanged != null ? whatChanged : new ArrayList<>();
        this.whyItMatters = whyItMatters != null ? whyItMatters : new ArrayList<>();
        this.whatCanIVerify = whatCanIVerify != null ? whatCanIVerify : new ArrayList<>();
    }

    public List<RiskSignalDto> getWhatChanged() {
        return whatChanged;
    }

    public void setWhatChanged(List<RiskSignalDto> whatChanged) {
        this.whatChanged = whatChanged;
    }

    public List<RiskSignalDto> getWhyItMatters() {
        return whyItMatters;
    }

    public void setWhyItMatters(List<RiskSignalDto> whyItMatters) {
        this.whyItMatters = whyItMatters;
    }

    public List<RiskSignalDto> getWhatCanIVerify() {
        return whatCanIVerify;
    }

    public void setWhatCanIVerify(List<RiskSignalDto> whatCanIVerify) {
        this.whatCanIVerify = whatCanIVerify;
    }
}
