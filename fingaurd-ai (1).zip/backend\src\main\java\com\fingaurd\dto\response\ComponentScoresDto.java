package com.fingaurd.dto.response;

public class ComponentScoresDto {

    private Double escalationScore;
    private Double escalationMax = 30.0;

    private Double baselineDeviationScore;
    private Double baselineMax = 25.0;

    private Double velocityScore;
    private Double velocityMax = 20.0;

    private Double influenceScore;
    private Double influenceMax = 25.0;

    private Boolean redistributed = false;

    public ComponentScoresDto() {}

    public ComponentScoresDto(Double escalationScore, Double baselineDeviationScore, Double velocityScore, Double influenceScore, Boolean redistributed) {
        this.escalationScore = escalationScore;
        this.baselineDeviationScore = baselineDeviationScore;
        this.velocityScore = velocityScore;
        this.influenceScore = influenceScore;
        this.redistributed = redistributed != null ? redistributed : false;
    }

    public Double getEscalationScore() {
        return escalationScore;
    }

    public void setEscalationScore(Double escalationScore) {
        this.escalationScore = escalationScore;
    }

    public Double getEscalationMax() {
        return escalationMax;
    }

    public void setEscalationMax(Double escalationMax) {
        this.escalationMax = escalationMax;
    }

    public Double getBaselineDeviationScore() {
        return baselineDeviationScore;
    }

    public void setBaselineDeviationScore(Double baselineDeviationScore) {
        this.baselineDeviationScore = baselineDeviationScore;
    }

    public Double getBaselineMax() {
        return baselineMax;
    }

    public void setBaselineMax(Double baselineMax) {
        this.baselineMax = baselineMax;
    }

    public Double getVelocityScore() {
        return velocityScore;
    }

    public void setVelocityScore(Double velocityScore) {
        this.velocityScore = velocityScore;
    }

    public Double getVelocityMax() {
        return velocityMax;
    }

    public void setVelocityMax(Double velocityMax) {
        this.velocityMax = velocityMax;
    }

    public Double getInfluenceScore() {
        return influenceScore;
    }

    public void setInfluenceScore(Double influenceScore) {
        this.influenceScore = influenceScore;
    }

    public Double getInfluenceMax() {
        return influenceMax;
    }

    public void setInfluenceMax(Double influenceMax) {
        this.influenceMax = influenceMax;
    }

    public Boolean getRedistributed() {
        return redistributed;
    }

    public void setRedistributed(Boolean redistributed) {
        this.redistributed = redistributed;
    }
}
