import React, { useEffect, useState } from 'react';
import { auditService, consentService } from '../services/api';
import { AuditEvent, ConsentRecord } from '../types';
import { formatDate } from '../utils/formatters';
import {
  ShieldCheck, Lock, History, CheckCircle2,
  XCircle, Database, ShieldAlert
} from 'lucide-react';

export const PrivacyAuditPage: React.FC = () => {
  const [events, setEvents] = useState<AuditEvent[]>([]);
  const [consent, setConsent] = useState<ConsentRecord | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAuditData = async () => {
      try {
        setLoading(true);
        const [evs, c] = await Promise.all([
          auditService.getEvents().catch(() => []),
          consentService.get().catch(() => null),
        ]);
        setEvents(evs);
        setConsent(c);
      } finally {
        setLoading(false);
      }
    };
    fetchAuditData();
  }, []);

  const handleToggleConsent = async () => {
    const nextVal = !consent?.granted;
    try {
      const updated = await consentService.set('COMMUNICATION_ANALYSIS', nextVal);
      setConsent(updated);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <h1 className="text-2xl font-heading font-black tracking-tight text-[#0F1F2E] flex items-center gap-2">
          <ShieldCheck className="w-6 h-6 text-[#1F5F5B]" />
          Privacy & Audit Log
        </h1>
        <p className="text-xs text-[#5B6B7A]">
          Complete transparency over user consent records, system access logs, and data security boundaries.
        </p>
      </div>

      {/* Data Boundaries: What is Stored vs What is NEVER Stored */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-fin border border-[#E4E8E4] shadow-fin-card space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-[#1F5F5B]">
            <CheckCircle2 className="w-4 h-4 text-[#5FA37A]" />
            <span>What Fingaurd AI Stores</span>
          </div>
          <ul className="text-xs text-[#5B6B7A] space-y-2">
            <li>• Investment amounts and dates entered by user or CSV.</li>
            <li>• Reconstructed mathematical journey baseline stats (μ, σ, max).</li>
            <li>• Generated pre-commitment risk scores and audit timestamps.</li>
            <li>• Cryptographically hashed authentication credentials (BCrypt).</li>
          </ul>
        </div>

        <div className="bg-white p-6 rounded-fin border border-[#E4E8E4] shadow-fin-card space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-[#B4414B]">
            <XCircle className="w-4 h-4 text-[#B4414B]" />
            <span>What Fingaurd AI NEVER Accesses or Stores</span>
          </div>
          <ul className="text-xs text-[#5B6B7A] space-y-2">
            <li>• <strong>No Bank Account or UPI Access:</strong> No Netbanking, MPIN, or account balances.</li>
            <li>• <strong>No Payment Gateway Routing:</strong> Transactions are never processed here.</li>
            <li>• <strong>No Persistent Sender Identity:</strong> Communication text is scanned in ephemeral memory.</li>
            <li>• <strong>No Third-Party Ad Trackers:</strong> Zero advertising networks or telemarketing feeds.</li>
          </ul>
        </div>
      </div>

      {/* Consent Toggle */}
      <div className="bg-white p-6 rounded-fin border border-[#E4E8E4] shadow-fin-card space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-heading font-extrabold text-sm text-[#0F1F2E]">
              Natural Language Processing Consent
            </h3>
            <p className="text-xs text-[#5B6B7A]">
              Controls whether heuristic persuasion pattern scanning is permitted on communication text.
            </p>
          </div>

          <button
            onClick={handleToggleConsent}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              consent?.granted
                ? 'bg-[#E6F2EA] text-[#5FA37A] border border-[#A4D1B5]'
                : 'bg-gray-100 text-gray-500 border border-gray-200'
            }`}
          >
            {consent?.granted ? 'Consent Granted (Active)' : 'Consent Revoked (Opted Out)'}
          </button>
        </div>
      </div>

      {/* Immutable Audit Event Log Table */}
      <div className="bg-white p-6 rounded-fin border border-[#E4E8E4] shadow-fin-card space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-[#1F5F5B]" />
            <h3 className="font-heading font-extrabold text-sm text-[#0F1F2E]">
              Account Audit Event Trail
            </h3>
          </div>
          <span className="text-[11px] text-[#5B6B7A]">
            Showing recent recorded security and analysis events
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#F5F6F3] border-b border-[#E4E8E4] text-[#5B6B7A] uppercase text-[10px] font-bold">
              <tr>
                <th className="py-2.5 px-3">Timestamp</th>
                <th className="py-2.5 px-3">Actor</th>
                <th className="py-2.5 px-3">Action</th>
                <th className="py-2.5 px-3">Resource</th>
                <th className="py-2.5 px-3 text-right">Result</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E4E8E4]">
              {events.map((ev) => (
                <tr key={ev.eventId} className="hover:bg-gray-50/70">
                  <td className="py-2.5 px-3 font-mono text-[11px] text-[#5B6B7A] whitespace-nowrap">
                    {formatDate(ev.timestamp)}
                  </td>
                  <td className="py-2.5 px-3 font-medium text-[#0F1F2E]">{ev.actor}</td>
                  <td className="py-2.5 px-3">
                    <span className="px-2 py-0.5 rounded bg-gray-100 text-[#0F1F2E] font-mono text-[10px]">
                      {ev.action}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-gray-600">{ev.resource}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-[#1F5F5B]">{ev.result}</td>
                </tr>
              ))}
              {events.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-xs text-[#5B6B7A]">
                    No audit records logged yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default PrivacyAuditPage;
