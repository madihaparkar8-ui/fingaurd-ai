package com.fingaurd.repository;

import com.fingaurd.model.ConsentRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface ConsentRecordRepository extends JpaRepository<ConsentRecord, Long> {
    Optional<ConsentRecord> findTopByUserIdAndPurposeOrderByTimestampDesc(Long userId, String purpose);
}
