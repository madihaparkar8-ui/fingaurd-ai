package com.fingaurd.controller;

import com.fingaurd.dto.request.LoginRequest;
import com.fingaurd.dto.response.AuthResponse;
import com.fingaurd.model.User;
import com.fingaurd.service.DemoSeedService;
import com.fingaurd.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/demo")
public class DemoController {

    private final DemoSeedService demoSeedService;
    private final UserService userService;

    public DemoController(DemoSeedService demoSeedService, UserService userService) {
        this.demoSeedService = demoSeedService;
        this.userService = userService;
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> quickDemoLogin() {
        AuthResponse resp = userService.authenticate(new LoginRequest(DemoSeedService.DEMO_EMAIL, DemoSeedService.DEMO_PASSWORD));
        return ResponseEntity.ok(resp);
    }

    @PostMapping("/seed")
    public ResponseEntity<Map<String, String>> seedJourney(@AuthenticationPrincipal UserDetails userDetails,
                                                           @RequestParam(defaultValue = "TRUST_TO_COMMITMENT") String type) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        demoSeedService.loadPresetJourney(user, type);
        return ResponseEntity.ok(Map.of("status", "SUCCESS", "preset", type, "message", "Loaded synthetic journey: " + type));
    }
}
