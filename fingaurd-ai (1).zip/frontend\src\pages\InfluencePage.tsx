import React, { useState } from 'react';
import { communicationService } from '../services/api';
import { InfluenceAnalysis } from '../types';
import {
  MessageSquareWarning, Sparkles, CheckCircle2,
  AlertTriangle, ArrowRight, ShieldCheck, Info
} from 'lucide-react';

export const InfluencePage: React.FC = () => {
  const [text, setText] = useState(
    "Hello sir! Congratulations on your previous payout! Our VIP group quota is closing in next 2 hours. This is your last chance today. Special guaranteed 35% assured returns from our SEBI registered guru. Transfer ₹4,00,000 immediately to lock your VIP slot. Limited slots only 3 left! To release your withdrawal fast, deposit the full amount now!"
  );
  const [consentGranted, setConsentGranted] = useState(true);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<InfluenceAnalysis | null>(null);

  const handleAnalyse = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || !consentGranted) return;

    try {
      setLoading(true);
      const res = await communicationService.analyse({
        text,
        consentGranted,
      });
      setResult(res);
    } catch (err: any) {
      alert(err?.response?.data?.message || 'Influence analysis failed');
    } finally {
      setLoading(false);
    }
  };

  const handlePasteBenign = () => {
    setText("Dear Rahul, please find attached the monthly statement for your portfolio. Let us know if you have questions.");
    setResult(null);
  };

  const handlePasteUrgent = () => {
    setText("Urgent transfer required within 2 hours! Final payment required to unlock your funds. 100% guaranteed returns from our certified financial guru.");
    setResult(null);
  };

  // Helper function to render text with matched evidence highlighted inline
  const renderHighlightedText = () => {
    if (!result || !result.detectedCategories || result.detectedCategories.length === 0) {
      return <span>{text}</span>;
    }

    // Collect all matched words/phrases
    const allEvidence = result.detectedCategories.flatMap((c) => c.matchedEvidence);
    const sorted = Array.from(new Set(allEvidence)).sort((a, b) => b.length - a.length);

    if (sorted.length === 0) return <span>{text}</span>;

    const regex = new RegExp(`(${sorted.map((s) => s.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&')).join('|')})`, 'gi');
    const parts = text.split(regex);

    return parts.map((part, i) => {
      const isMatch = sorted.some((s) => s.toLowerCase() === part.toLowerCase());
      if (isMatch) {
        return (
          <mark
            key={i}
            className="bg-[#FBE9E0] text-[#B4414B] font-bold px-1.5 py-0.5 rounded border border-[#F0BC9F]"
          >
            {part}
          </mark>
        );
      }
      return <span key={i}>{part}</span>;
    });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-heading font-black tracking-tight text-[#0F1F2E] flex items-center gap-2">
          <MessageSquareWarning className="w-6 h-6 text-[#1F5F5B]" />
          Communication Influence Analysis
        </h1>
        <p className="text-xs text-[#5B6B7A]">
          Opt-in natural language heuristic engine detecting coercive persuasion patterns in investment messages.
        </p>
      </div>

      <div className="bg-white p-6 sm:p-8 rounded-fin border border-[#E4E8E4] shadow-fin-card space-y-6">
        <form onSubmit={handleAnalyse} className="space-y-4">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-[#0F1F2E]">
              Investment Communication Text
            </label>
            <div className="flex items-center gap-2 text-xs">
              <button
                type="button"
                onClick={handlePasteBenign}
                className="text-[11px] font-semibold text-[#5B6B7A] hover:text-[#0F1F2E]"
              >
                Sample Benign Text
              </button>
              <span>•</span>
              <button
                type="button"
                onClick={handlePasteUrgent}
                className="text-[11px] font-bold text-[#1F5F5B] hover:underline"
              >
                Sample Urgent Pressure Text
              </button>
            </div>
          </div>

          <textarea
            rows={5}
            required
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Paste communication received here..."
            className="w-full p-3.5 text-xs rounded-xl border border-[#E4E8E4] focus:outline-none focus:border-[#1F5F5B] text-[#0F1F2E]"
          />

          <label className="flex items-start gap-2.5 cursor-pointer">
            <input
              type="checkbox"
              checked={consentGranted}
              onChange={(e) => setConsentGranted(e.target.checked)}
              className="mt-0.5 rounded text-[#1F5F5B] focus:ring-[#1F5F5B] accent-[#1F5F5B]"
            />
            <div className="text-[11px] text-[#5B6B7A]">
              <strong className="text-[#0F1F2E]">User Consent Granted:</strong> I authorize heuristic keyword and pattern analysis on this text for manipulation safety signals.
            </div>
          </label>

          <button
            type="submit"
            disabled={loading || !consentGranted || !text.trim()}
            className="w-full py-3 px-6 rounded-xl text-xs font-bold bg-[#1F5F5B] text-white hover:bg-[#2A7A74] transition-all flex items-center justify-center gap-2 shadow-2xs disabled:opacity-50"
          >
            {loading ? 'Evaluating Heuristic Lexicons...' : 'Analyse Persuasion Patterns'}
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Results Presentation */}
        {result && (
          <div className="pt-6 border-t border-[#E4E8E4] space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h3 className="font-heading font-extrabold text-base text-[#0F1F2E]">
                  {result.heading}
                </h3>
                <p className="text-xs text-[#5B6B7A]">
                  Evaluated across 7 Indian financial manipulation dictionaries.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className={`px-3 py-1 rounded-full text-xs font-extrabold ${
                  result.indicatorsDetected
                    ? 'bg-[#FBE9E0] text-[#B4414B] border border-[#F0BC9F]'
                    : 'bg-[#E6F2EA] text-[#5FA37A] border border-[#A4D1B5]'
                }`}>
                  {result.indicatorsDetected ? 'Manipulation Indicators Detected' : 'No Indicators Found'}
                </span>
              </div>
            </div>

            {/* Inline Highlighted Text View */}
            <div className="p-4 rounded-xl bg-[#F5F6F3] border border-[#E4E8E4] text-xs leading-relaxed text-[#0F1F2E] font-medium space-y-1">
              <div className="text-[10px] uppercase font-bold text-[#5B6B7A] mb-1">Inline Evidence Highlights:</div>
              {renderHighlightedText()}
            </div>

            {/* Detected Categories List */}
            {result.detectedCategories.length > 0 ? (
              <div className="space-y-3">
                <h4 className="font-heading font-bold text-xs uppercase text-[#5B6B7A] tracking-wider">
                  Detected Linguistic Categories ({result.detectedCategories.length})
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {result.detectedCategories.map((cat, i) => (
                    <div key={i} className="p-4 rounded-xl bg-white border border-[#E4E8E4] shadow-xs space-y-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <span className="font-bold text-xs text-[#0F1F2E]">{cat.label}</span>
                          <div className="text-[10px] text-gray-500 font-mono">{cat.category}</div>
                        </div>
                        <span className="font-extrabold text-xs text-[#B4414B] font-tabular">
                          {(cat.confidence * 100).toFixed(0)}%
                        </span>
                      </div>

                      <div className="w-full bg-gray-100 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-[#B4414B] h-full rounded-full"
                          style={{ width: `${cat.confidence * 100}%` }}
                        />
                      </div>

                      <div className="text-[11px] text-[#5B6B7A]">
                        Matched terms: <strong className="text-[#0F1F2E]">{cat.matchedEvidence.join(', ')}</strong>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="p-6 rounded-xl bg-[#E6F2EA] border border-[#A4D1B5] text-xs text-[#5FA37A] flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                <span>No high-pressure urgency, guaranteed returns, or withdrawal unlock fee patterns detected.</span>
              </div>
            )}

            <div className="p-3.5 rounded-xl bg-[#F5F6F3] text-[11px] text-[#5B6B7A] italic leading-tight">
              {result.disclaimer}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default InfluencePage;
