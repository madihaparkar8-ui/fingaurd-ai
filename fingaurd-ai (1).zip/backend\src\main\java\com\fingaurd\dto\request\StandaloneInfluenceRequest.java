package com.fingaurd.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class StandaloneInfluenceRequest {

    @NotBlank(message = "Communication text is required")
    private String text;

    @NotNull(message = "Consent status is required")
    private Boolean consentGranted;

    public StandaloneInfluenceRequest() {}

    public StandaloneInfluenceRequest(String text, Boolean consentGranted) {
        this.text = text;
        this.consentGranted = consentGranted;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Boolean getConsentGranted() {
        return consentGranted;
    }

    public void setConsentGranted(Boolean consentGranted) {
        this.consentGranted = consentGranted;
    }
}
