package com.fingaurd.service;

import com.fingaurd.dto.response.AnomalyEnsembleDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class DeviationAnomalyDetector {

    @Value("${fingaurd.risk.anomaly-z-weight:0.4}")
    private double zWeight;

    @Value("${fingaurd.risk.anomaly-step-weight:0.3}")
    private double stepWeight;

    @Value("${fingaurd.risk.anomaly-maxratio-weight:0.3}")
    private double maxRatioWeight;

    @Value("${fingaurd.risk.z-cutoff:2.0}")
    private double zCutoff;

    @Value("${fingaurd.risk.z-span:3.0}")
    private double zSpan;

    @Value("${fingaurd.risk.step-cutoff:2.0}")
    private double stepCutoff;

    @Value("${fingaurd.risk.step-span:3.0}")
    private double stepSpan;

    @Value("${fingaurd.risk.maxratio-cutoff:1.5}")
    private double maxRatioCutoff;

    @Value("${fingaurd.risk.maxratio-span:3.5}")
    private double maxRatioSpan;

    public static double clamp01(double val) {
        if (Double.isNaN(val) || val <= 0.0) return 0.0;
        if (val >= 1.0) return 1.0;
        return val;
    }

    public AnomalyEnsembleDto calculateAnomalyEnsemble(JourneyFeatures features) {
        double z = features.getBaselineZScore();
        double absZ = Math.abs(z);
        double maxStepRatio = features.getMaxConsecutiveStepRatio();
        double histMaxRatio = features.getHistoricalMaxRatio();

        // 1. zScoreSignal = clamp01((|z| - 2.0) / 3.0)
        double zScoreSignal = clamp01((absZ - zCutoff) / zSpan);

        // 2. stepChangeSignal = clamp01((maxStepRatio - 2.0) / 3.0)
        double stepChangeSignal = clamp01((maxStepRatio - stepCutoff) / stepSpan);

        // 3. maxRatioSignal = clamp01((historicalMaxRatio - 1.5) / 3.5)
        double maxRatioSignal = clamp01((histMaxRatio - maxRatioCutoff) / maxRatioSpan);

        // 4. Anomaly score ensemble
        double anomalyScore = (zWeight * zScoreSignal) + (stepWeight * stepChangeSignal) + (maxRatioWeight * maxRatioSignal);

        AnomalyEnsembleDto dto = new AnomalyEnsembleDto();
        dto.setzScoreSignal(round(zScoreSignal, 4));
        dto.setStepChangeSignal(round(stepChangeSignal, 4));
        dto.setMaxRatioSignal(round(maxRatioSignal, 4));
        dto.setAnomalyScore(round(anomalyScore, 4));

        dto.setzScore(round(z, 2));
        dto.setMaxStepRatio(round(maxStepRatio, 2));
        dto.setHistoricalMaxRatio(round(histMaxRatio, 2));
        dto.setVelocityPerDay(round(features.getCommitmentVelocity(), 2));
        dto.setEntityConcentration(round(features.getEntityConcentration(), 4));
        dto.setReturnFollowedByEscalation(features.isReturnFollowedByEscalation());

        return dto;
    }

    private double round(double val, int decimals) {
        double factor = Math.pow(10, decimals);
        return Math.round(val * factor) / factor;
    }
}
