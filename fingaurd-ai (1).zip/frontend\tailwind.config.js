/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        canvas: {
          light: '#F5F6F3',
          dark: '#0C1822',
        },
        surface: {
          light: '#FFFFFF',
          dark: '#13222E',
        },
        ink: {
          primary: '#0F1F2E',
          secondary: '#5B6B7A',
          border: '#E4E8E4',
          borderDark: '#1E2D3D',
        },
        brand: {
          primary: '#1F5F5B',
          hover: '#2A7A74',
          tint: '#E3F0EE',
          gold: '#C9A24A',
        },
        risk: {
          low: '#5FA37A',
          lowBg: '#E6F2EA',
          moderate: '#D9A441',
          moderateBg: '#FBF1DB',
          high: '#D9784A',
          highBg: '#FBE9E0',
          critical: '#B4414B',
          criticalBg: '#F6E2E4',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        heading: ['"Plus Jakarta Sans"', 'Manrope', 'system-ui', 'sans-serif'],
      },
      borderRadius: {
        'fin': '18px',
      },
      boxShadow: {
        'fin-card': '0 4px 20px -2px rgba(15, 31, 46, 0.05), 0 2px 6px -1px rgba(15, 31, 46, 0.03)',
        'fin-hover': '0 10px 25px -4px rgba(31, 95, 91, 0.12), 0 4px 10px -2px rgba(31, 95, 91, 0.06)',
      }
    },
  },
  plugins: [],
}
