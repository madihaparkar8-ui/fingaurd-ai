import React, { useEffect, useState } from 'react';
import { useSearchParams, Link, useNavigate } from 'react-router-dom';
import { riskService } from '../services/api';
import { RiskReport } from '../types';
import { formatINR, formatDate, getRiskBandDetails } from '../utils/formatters';
import { RiskGauge } from '../components/RiskGauge';
import {
  FileCheck2, AlertTriangle, ArrowRight, Printer,
  Eye, CheckCircle2, ShieldAlert, Sparkles, Scale, Info, Brain, Lightbulb
} from 'lucide-react';

export const ReportPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const reportIdParam = searchParams.get('id');

  const [report, setReport] = useState<RiskReport | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchReport = async () => {
      try {
        setLoading(true);
        if (reportIdParam) {
          const rep = await riskService.getReport(Number(reportIdParam));
          setReport(rep);
        } else {
          const list = await riskService.getHistory();
          if (list.length > 0) {
            setReport(list[0]);
          }
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchReport();
  }, [reportIdParam]);

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-10 bg-gray-200 rounded-xl w-60" />
        <div className="h-96 bg-gray-200 rounded-2xl" />
      </div>
    );
  }

  if (!report) {
    return (
      <div className="p-12 text-center bg-white rounded-2xl border border-[#E4E8E4] space-y-4">
        <FileCheck2 className="w-12 h-12 text-gray-300 mx-auto" />
        <h3 className="font-heading font-bold text-lg text-[#0F1F2E]">No Risk Report Found</h3>
        <p className="text-xs text-[#5B6B7A]">Run a pre-commitment check to generate an explainable report.</p>
        <Link
          to="/analyse"
          className="inline-block px-5 py-2.5 rounded-xl text-xs font-bold bg-[#1F5F5B] text-white hover:bg-[#2A7A74]"
        >
          Run Analysis
        </Link>
      </div>
    );
  }

  const band = getRiskBandDetails(report.overallScore);
  const comp = report.componentScoresDetail;
  const anomaly = report.anomalyEnsemble;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Action Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 no-print">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-md bg-[#E3F0EE] text-[#1F5F5B] text-[10px] font-extrabold uppercase tracking-wider">
              Prototype Score
            </span>
            <span className="text-xs text-[#5B6B7A]">Report #{report.reportId}</span>
          </div>
          <h1 className="text-2xl font-heading font-black tracking-tight text-[#0F1F2E] mt-1">
            Pre-Commitment Risk Report
          </h1>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePrint}
            className="px-3.5 py-2 rounded-xl text-xs font-bold border border-[#E4E8E4] bg-white text-[#0F1F2E] hover:bg-gray-50 flex items-center gap-1.5 shadow-2xs"
          >
            <Printer className="w-3.5 h-3.5 text-[#5B6B7A]" />
            <span>Download PDF</span>
          </button>

          <Link
            to={`/what-changed?id=${report.reportId}`}
            className="px-3.5 py-2 rounded-xl text-xs font-bold bg-white border border-[#1F5F5B] text-[#1F5F5B] hover:bg-[#E3F0EE] flex items-center gap-1.5 shadow-2xs"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>What Changed?</span>
          </Link>

          <Link
            to={`/pause?id=${report.reportId}`}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-[#B4414B] text-white hover:bg-[#9B333C] flex items-center gap-1.5 shadow-2xs"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Pause Screen</span>
          </Link>
        </div>
      </div>

      {/* Main Hero Card with Animated Gauge & Target Details */}
      <div className="bg-white p-6 sm:p-8 rounded-fin border border-[#E4E8E4] shadow-fin-card space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          <div className="md:col-span-5 flex justify-center border-b md:border-b-0 md:border-r border-[#E4E8E4] pb-6 md:pb-0 md:pr-6">
            <RiskGauge score={report.overallScore} size={280} animate={true} />
          </div>

          <div className="md:col-span-7 space-y-4">
            <div>
              <span className="text-[10px] uppercase font-bold text-[#5B6B7A] tracking-wider">
                Target Commitment Under Review
              </span>
              <div className="text-3xl font-black font-heading text-[#0F1F2E] font-tabular mt-0.5">
                {formatINR(report.targetInvestment)}
              </div>
              <div className="text-sm font-bold text-[#1F5F5B] mt-0.5">
                Recipient: {report.targetEntity}
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-[#F5F6F3] border border-[#E4E8E4] text-xs text-[#0F1F2E] space-y-1">
              <div className="flex justify-between">
                <span className="text-[#5B6B7A]">Assessment Timestamp:</span>
                <span className="font-medium">{formatDate(report.createdAt)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#5B6B7A]">Communication Analysis:</span>
                <span className="font-semibold text-[#1F5F5B]">
                  {report.communicationUsed ? 'Consent Granted & Analyzed' : 'No Communication Analyzed (Redistributed 100/75)'}
                </span>
              </div>
            </div>

            <div className="text-[11px] text-[#5B6B7A] italic leading-tight">
              {report.disclaimer}
            </div>
          </div>
        </div>

        {/* Component Score Breakdown (Horizontal Bars 30 / 25 / 20 / 25) */}
        {comp && (
          <div className="pt-6 border-t border-[#E4E8E4] space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-heading font-extrabold text-sm text-[#0F1F2E]">
                Component Sub-Score Breakdown
              </h3>
              {comp.redistributed && (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200">
                  Scale factor 100/75 applied (No communication)
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Financial Escalation (Max 30) */}
              <div className="p-4 rounded-xl bg-[#F5F6F3] border border-[#E4E8E4] space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="font-bold text-[#0F1F2E]">Financial Escalation</span>
                  <span className="font-extrabold text-[#1F5F5B] font-tabular">
                    {comp.escalationScore} / {comp.escalationMax}
                  </span>
                </div>
                <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-[#1F5F5B] h-full rounded-full transition-all duration-500"
                    style={{ width: `${(comp.escalationScore / comp.escalationMax) * 100}%` }}
                  />
                </div>
                <div className="text-[10px] text-[#5B6B7A]">
                  Ratio vs historical maximum & step surges.
                </div>
              </div>

              {/* Personal Baseline Deviation (Max 25) */}
              <div className="p-4 rounded-xl bg-[#F5F6F3] border border-[#E4E8E4] space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="font-bold text-[#0F1F2E]">Personal Baseline Deviation</span>
                  <span className="font-extrabold text-[#1F5F5B] font-tabular">
                    {comp.baselineDeviationScore} / {comp.baselineMax}
                  </span>
                </div>
                <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-[#1F5F5B] h-full rounded-full transition-all duration-500"
                    style={{ width: `${(comp.baselineDeviationScore / comp.baselineMax) * 100}%` }}
                  />
                </div>
                <div className="text-[10px] text-[#5B6B7A]">
                  Z-score deviation from personal mean (μ).
                </div>
              </div>

              {/* Commitment Velocity (Max 20) */}
              <div className="p-4 rounded-xl bg-[#F5F6F3] border border-[#E4E8E4] space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="font-bold text-[#0F1F2E]">Commitment Velocity</span>
                  <span className="font-extrabold text-[#1F5F5B] font-tabular">
                    {comp.velocityScore} / {comp.velocityMax}
                  </span>
                </div>
                <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-[#1F5F5B] h-full rounded-full transition-all duration-500"
                    style={{ width: `${(comp.velocityScore / comp.velocityMax) * 100}%` }}
                  />
                </div>
                <div className="text-[10px] text-[#5B6B7A]">
                  Rate of capital accumulation (₹/day) over duration.
                </div>
              </div>

              {/* Influence NLP Score (Max 25) */}
              <div className="p-4 rounded-xl bg-[#F5F6F3] border border-[#E4E8E4] space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="font-bold text-[#0F1F2E]">Communication Influence</span>
                  <span className="font-extrabold text-[#1F5F5B] font-tabular">
                    {comp.influenceScore} / {comp.influenceMax}
                  </span>
                </div>
                <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-[#1F5F5B] h-full rounded-full transition-all duration-500"
                    style={{ width: `${(comp.influenceScore / comp.influenceMax) * 100}%` }}
                  />
                </div>
                <div className="text-[10px] text-[#5B6B7A]">
                  {report.communicationUsed
                    ? 'Confidence blend across 7 manipulation categories.'
                    : 'Not provided / consented.'}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Anomaly Ensemble Breakdown */}
        {anomaly && (
          <div className="pt-6 border-t border-[#E4E8E4] space-y-3">
            <h3 className="font-heading font-extrabold text-sm text-[#0F1F2E]">
              Anomaly Ensemble Formulation
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-white border border-[#E4E8E4]">
                <div className="text-[10px] text-[#5B6B7A] uppercase font-bold">zScoreSignal (0.4×)</div>
                <div className="text-base font-extrabold text-[#0F1F2E] font-tabular mt-0.5">
                  {anomaly.zScoreSignal}
                </div>
                <div className="text-[10px] text-gray-500">z = {anomaly.zScore}σ</div>
              </div>

              <div className="p-3 rounded-xl bg-white border border-[#E4E8E4]">
                <div className="text-[10px] text-[#5B6B7A] uppercase font-bold">stepChange (0.3×)</div>
                <div className="text-base font-extrabold text-[#0F1F2E] font-tabular mt-0.5">
                  {anomaly.stepChangeSignal}
                </div>
                <div className="text-[10px] text-gray-500">ratio = {anomaly.maxStepRatio}×</div>
              </div>

              <div className="p-3 rounded-xl bg-white border border-[#E4E8E4]">
                <div className="text-[10px] text-[#5B6B7A] uppercase font-bold">maxRatio (0.3×)</div>
                <div className="text-base font-extrabold text-[#0F1F2E] font-tabular mt-0.5">
                  {anomaly.maxRatioSignal}
                </div>
                <div className="text-[10px] text-gray-500">ratio = {anomaly.historicalMaxRatio}×</div>
              </div>

              <div className="p-3 rounded-xl bg-[#E3F0EE] border border-[#BCE1DB]">
                <div className="text-[10px] text-[#1F5F5B] uppercase font-bold">Anomaly Score</div>
                <div className="text-base font-black text-[#1F5F5B] font-tabular mt-0.5">
                  {anomaly.anomalyScore}
                </div>
                <div className="text-[10px] text-[#1F5F5B]">Ensemble weighted</div>
              </div>
            </div>
          </div>
        )}

        {/* Contributing Risk Signals */}
        {report.signals && report.signals.length > 0 && (
          <div className="pt-6 border-t border-[#E4E8E4] space-y-3">
            <h3 className="font-heading font-extrabold text-sm text-[#0F1F2E]">
              Key Behavioural Risk Signals
            </h3>
            <div className="space-y-2">
              {report.signals.map((sig, idx) => (
                <div key={idx} className="p-3.5 rounded-xl bg-[#F5F6F3] border border-[#E4E8E4] flex items-start gap-3 text-xs">
                  <div className="w-6 h-6 rounded-lg bg-[#E3F0EE] text-[#1F5F5B] flex items-center justify-center flex-shrink-0 font-bold text-xs">
                    {idx + 1}
                  </div>
                  <div className="flex-1 space-y-0.5">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-[#0F1F2E]">{sig.type}</span>
                      <span className="font-bold text-[#1F5F5B] font-tabular">{sig.value}</span>
                    </div>
                    <p className="text-[#5B6B7A] leading-relaxed text-[11px]">{sig.explanation}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Detected Behavioural Biases & Cognitive Traps */}
        {report.behaviouralBiases && report.behaviouralBiases.length > 0 && (
          <div className="pt-6 border-t border-[#E4E8E4] space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Brain className="w-4 h-4 text-[#1F5F5B]" />
                <h3 className="font-heading font-extrabold text-sm text-[#0F1F2E]">
                  Detected Cognitive Biases & Psychological Vulnerabilities ({report.behaviouralBiases.length})
                </h3>
              </div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-[#FBE9E0] text-[#D9784A] border border-[#F0BC9F]">
                Behavioural Friction Active
              </span>
            </div>

            <div className="space-y-3">
              {report.behaviouralBiases.map((bias, idx) => (
                <div key={idx} className="p-4 rounded-xl bg-[#F5F6F3] border border-[#E4E8E4] space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-[#1F5F5B] text-white flex items-center justify-center font-bold text-[10px]">
                        {idx + 1}
                      </span>
                      <h4 className="font-heading font-bold text-xs sm:text-sm text-[#0F1F2E]">
                        {bias.title}
                      </h4>
                    </div>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-wider ${
                      bias.severity === 'HIGH'
                        ? 'bg-[#FBE9E0] text-[#B4414B] border border-[#F0BC9F]'
                        : 'bg-[#FBF1DB] text-[#D9A441] border border-[#F0D49C]'
                    }`}>
                      {bias.severity} Vulnerability
                    </span>
                  </div>

                  <div className="text-[11px] text-[#5B6B7A] leading-relaxed">
                    <strong className="text-[#0F1F2E]">Observed Trigger: </strong>
                    {bias.triggerEvidence}
                  </div>

                  <div className="p-3 rounded-lg bg-white border border-[#E4E8E4] text-[11px] space-y-1.5">
                    <div className="flex items-start gap-1.5 text-[#5B6B7A]">
                      <Brain className="w-3.5 h-3.5 text-[#1F5F5B] flex-shrink-0 mt-0.5" />
                      <div>
                        <strong className="text-[#0F1F2E]">Psychological Mechanism: </strong>
                        {bias.psychologicalMechanism}
                      </div>
                    </div>
                    <div className="flex items-start gap-1.5 text-[#1F5F5B]">
                      <Lightbulb className="w-3.5 h-3.5 text-[#C9A24A] flex-shrink-0 mt-0.5" />
                      <div>
                        <strong className="text-[#0F1F2E]">Recommended Countermeasure: </strong>
                        <span className="text-[#1F5F5B] font-medium">{bias.actionableCountermeasure}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ReportPage;
