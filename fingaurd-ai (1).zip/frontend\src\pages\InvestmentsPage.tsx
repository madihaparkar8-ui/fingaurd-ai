import React, { useEffect, useState } from 'react';
import { investmentService, demoService } from '../services/api';
import { Investment, InvestmentStatus } from '../types';
import { formatINR, formatDate } from '../utils/formatters';
import {
  Plus, Upload, Trash2, Edit2, Search, Filter, X,
  CheckCircle2, AlertCircle, FileSpreadsheet, Sparkles
} from 'lucide-react';

export const InvestmentsPage: React.FC = () => {
  const [investments, setInvestments] = useState<Investment[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [sortField, setSortField] = useState<'investedOn' | 'amount'>('investedOn');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  // Drawer state for Add / Edit
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    entityName: '',
    amount: '',
    investedOn: new Date().toISOString().split('T')[0],
    type: 'EQUITY',
    returnAmount: '',
    status: 'ACTIVE' as InvestmentStatus,
  });

  // CSV Modal state
  const [csvModalOpen, setCsvModalOpen] = useState(false);
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [csvPreview, setCsvPreview] = useState<string[][]>([]);
  const [csvResult, setCsvResult] = useState<{ totalRows: number; importedCount: number; failedCount: number; errors: string[] } | null>(null);
  const [csvUploading, setCsvUploading] = useState(false);

  // Demo journey switcher
  const [presetLoading, setPresetLoading] = useState(false);

  const fetchInvestments = async () => {
    try {
      setLoading(true);
      const data = await investmentService.getAll();
      setInvestments(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInvestments();
  }, []);

  const handleOpenAdd = () => {
    setEditingId(null);
    setFormData({
      entityName: '',
      amount: '',
      investedOn: new Date().toISOString().split('T')[0],
      type: 'EQUITY',
      returnAmount: '',
      status: 'ACTIVE',
    });
    setDrawerOpen(true);
  };

  const handleOpenEdit = (inv: Investment) => {
    setEditingId(inv.investmentId);
    setFormData({
      entityName: inv.entityName,
      amount: inv.amount.toString(),
      investedOn: inv.investedOn,
      type: inv.type || 'EQUITY',
      returnAmount: inv.returnAmount ? inv.returnAmount.toString() : '',
      status: inv.status,
    });
    setDrawerOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        entityName: formData.entityName,
        amount: Number(formData.amount),
        investedOn: formData.investedOn,
        type: formData.type,
        returnAmount: formData.returnAmount ? Number(formData.returnAmount) : null,
        status: formData.status,
      };

      if (editingId) {
        await investmentService.update(editingId, payload);
      } else {
        await investmentService.create(payload);
      }

      setDrawerOpen(false);
      fetchInvestments();
    } catch (err: any) {
      alert(err?.response?.data?.message || 'Error saving investment');
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm('Are you sure you want to delete this investment event?')) {
      try {
        await investmentService.delete(id);
        fetchInvestments();
      } catch (err) {
        console.error(err);
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setCsvFile(file);
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        const lines = text.split('\n').filter((l) => l.trim().length > 0);
        const rows = lines.slice(0, 5).map((l) => l.split(','));
        setCsvPreview(rows);
      };
      reader.readAsText(file);
    }
  };

  const handleCsvUpload = async () => {
    if (!csvFile) return;
    try {
      setCsvUploading(true);
      const res = await investmentService.importCsv(csvFile);
      setCsvResult(res);
      fetchInvestments();
    } catch (err: any) {
      alert(err?.response?.data?.message || 'CSV upload failed');
    } finally {
      setCsvUploading(false);
    }
  };

  const handleLoadPreset = async (preset: string) => {
    try {
      setPresetLoading(true);
      await demoService.seed(preset);
      await fetchInvestments();
    } catch (e) {
      console.error(e);
    } finally {
      setPresetLoading(false);
    }
  };

  // Filter & Sort
  const filtered = investments
    .filter((inv) => {
      const matchSearch =
        inv.entityName.toLowerCase().includes(search.toLowerCase()) ||
        inv.type.toLowerCase().includes(search.toLowerCase());
      const matchStatus = statusFilter === 'ALL' || inv.status === statusFilter;
      return matchSearch && matchStatus;
    })
    .sort((a, b) => {
      let valA = sortField === 'investedOn' ? new Date(a.investedOn).getTime() : Number(a.amount);
      let valB = sortField === 'investedOn' ? new Date(b.investedOn).getTime() : Number(b.amount);
      return sortOrder === 'asc' ? valA - valB : valB - valA;
    });

  return (
    <div className="space-y-6">
      {/* Title & Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-heading font-black tracking-tight text-[#0F1F2E]">
            Investment Commitments
          </h1>
          <p className="text-xs text-[#5B6B7A]">
            Manage, log, and import historical events to establish your personal behavioral baseline.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Preset journeys button */}
          <div className="relative group">
            <button
              disabled={presetLoading}
              className="px-3.5 py-2 rounded-xl text-xs font-bold border border-[#E4E8E4] bg-white text-[#0F1F2E] hover:bg-gray-50 flex items-center gap-1.5 shadow-2xs"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#C9A24A]" />
              <span>Load Journey Preset</span>
            </button>
            <div className="hidden group-hover:block absolute right-0 mt-1 w-56 bg-white rounded-xl shadow-xl border border-[#E4E8E4] py-1 z-30">
              <button
                onClick={() => handleLoadPreset('TRUST_TO_COMMITMENT')}
                className="w-full text-left px-3 py-1.5 text-xs hover:bg-[#E3F0EE] hover:text-[#1F5F5B]"
              >
                Trust-to-Commitment (Golden)
              </button>
              <button
                onClick={() => handleLoadPreset('NORMAL')}
                className="w-full text-left px-3 py-1.5 text-xs hover:bg-[#E3F0EE] hover:text-[#1F5F5B]"
              >
                Normal Portfolio
              </button>
              <button
                onClick={() => handleLoadPreset('GRADUAL')}
                className="w-full text-left px-3 py-1.5 text-xs hover:bg-[#E3F0EE] hover:text-[#1F5F5B]"
              >
                Gradual Escalation
              </button>
              <button
                onClick={() => handleLoadPreset('SUDDEN')}
                className="w-full text-left px-3 py-1.5 text-xs hover:bg-[#E3F0EE] hover:text-[#1F5F5B]"
              >
                Sudden Escalation
              </button>
              <button
                onClick={() => handleLoadPreset('REPEATED_ENTITY')}
                className="w-full text-left px-3 py-1.5 text-xs hover:bg-[#E3F0EE] hover:text-[#1F5F5B]"
              >
                Repeated-Entity Trap
              </button>
            </div>
          </div>

          <button
            onClick={() => { setCsvModalOpen(true); setCsvResult(null); setCsvFile(null); }}
            className="px-3.5 py-2 rounded-xl text-xs font-bold border border-[#E4E8E4] bg-white text-[#0F1F2E] hover:bg-gray-50 flex items-center gap-1.5 shadow-2xs"
          >
            <Upload className="w-3.5 h-3.5 text-[#1F5F5B]" />
            <span>Import CSV</span>
          </button>

          <button
            onClick={handleOpenAdd}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-[#1F5F5B] text-white hover:bg-[#2A7A74] flex items-center gap-1.5 shadow-2xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Event</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-2xl border border-[#E4E8E4] shadow-fin-card flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-[#5B6B7A] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search entity name or type..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-[#E4E8E4] focus:outline-none focus:border-[#1F5F5B] text-[#0F1F2E]"
          />
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto justify-end text-xs">
          <div className="flex items-center gap-1.5">
            <Filter className="w-3.5 h-3.5 text-[#5B6B7A]" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="py-1.5 px-2.5 rounded-lg border border-[#E4E8E4] text-[#0F1F2E] bg-white text-xs"
            >
              <option value="ALL">All Statuses</option>
              <option value="ACTIVE">ACTIVE</option>
              <option value="RETURNED">RETURNED</option>
              <option value="CLOSED">CLOSED</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-[#5B6B7A]">Sort:</span>
            <select
              value={`${sortField}-${sortOrder}`}
              onChange={(e) => {
                const [f, o] = e.target.value.split('-');
                setSortField(f as any);
                setSortOrder(o as any);
              }}
              className="py-1.5 px-2.5 rounded-lg border border-[#E4E8E4] text-[#0F1F2E] bg-white text-xs"
            >
              <option value="investedOn-desc">Date (Newest First)</option>
              <option value="investedOn-asc">Date (Oldest First)</option>
              <option value="amount-desc">Amount (Highest First)</option>
              <option value="amount-asc">Amount (Lowest First)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white rounded-2xl border border-[#E4E8E4] shadow-fin-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#F5F6F3] border-b border-[#E4E8E4] text-[#5B6B7A] uppercase font-bold text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Entity Name</th>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4 text-right">Amount (₹)</th>
                <th className="py-3 px-4 text-right">Return Payout (₹)</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E4E8E4]">
              {filtered.map((inv) => (
                <tr key={inv.investmentId} className="hover:bg-gray-50/70 transition-colors">
                  <td className="py-3.5 px-4 font-bold text-[#0F1F2E] flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-[#E3F0EE] text-[#1F5F5B] flex items-center justify-center font-bold text-xs flex-shrink-0">
                      {inv.entityName.charAt(0)}
                    </div>
                    <span className="truncate max-w-[220px]">{inv.entityName}</span>
                  </td>
                  <td className="py-3.5 px-4 text-[#5B6B7A] whitespace-nowrap">
                    {formatDate(inv.investedOn)}
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 rounded-md bg-gray-100 text-gray-700 text-[11px] font-medium">
                      {inv.type}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right font-extrabold text-[#0F1F2E] font-tabular">
                    {formatINR(inv.amount)}
                  </td>
                  <td className="py-3.5 px-4 text-right font-medium text-[#5FA37A] font-tabular">
                    {inv.returnAmount ? formatINR(inv.returnAmount) : '—'}
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <span
                      className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        inv.status === 'RETURNED'
                          ? 'bg-[#E6F2EA] text-[#5FA37A]'
                          : inv.status === 'ACTIVE'
                          ? 'bg-[#E3F0EE] text-[#1F5F5B]'
                          : 'bg-gray-100 text-gray-600'
                      }`}
                    >
                      {inv.status}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => handleOpenEdit(inv)}
                        className="p-1.5 rounded-lg text-gray-500 hover:text-[#1F5F5B] hover:bg-gray-100 transition-colors"
                        title="Edit Event"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(inv.investmentId)}
                        className="p-1.5 rounded-lg text-gray-500 hover:text-red-600 hover:bg-gray-100 transition-colors"
                        title="Delete Event"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}

              {filtered.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-[#5B6B7A] text-xs">
                    No investment records match your filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Slide-over Drawer for Add/Edit */}
      {drawerOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-black/30 backdrop-blur-xs flex justify-end">
          <div className="w-full max-w-md bg-white h-full shadow-2xl p-6 flex flex-col justify-between overflow-y-auto animate-in slide-in-from-right duration-200">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-[#E4E8E4]">
                <h3 className="text-lg font-heading font-extrabold text-[#0F1F2E]">
                  {editingId ? 'Edit Investment Commitment' : 'Add Investment Commitment'}
                </h3>
                <button
                  onClick={() => setDrawerOpen(false)}
                  className="p-1.5 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form id="drawerForm" onSubmit={handleSave} className="space-y-4 pt-6">
                <div>
                  <label className="block text-xs font-semibold text-[#0F1F2E] mb-1">
                    Recipient Entity / Platform Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.entityName}
                    onChange={(e) => setFormData({ ...formData, entityName: e.target.value })}
                    placeholder="e.g. Apex Wealth Advisory, Zerodha, Groww"
                    className="w-full px-3.5 py-2 text-xs rounded-xl border border-[#E4E8E4] focus:outline-none focus:border-[#1F5F5B]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#0F1F2E] mb-1">
                    Amount Invested (₹) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="1"
                    required
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    placeholder="e.g. 50000"
                    className="w-full px-3.5 py-2 text-xs rounded-xl border border-[#E4E8E4] focus:outline-none focus:border-[#1F5F5B]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#0F1F2E] mb-1">
                    Date of Commitment *
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.investedOn}
                    onChange={(e) => setFormData({ ...formData, investedOn: e.target.value })}
                    className="w-full px-3.5 py-2 text-xs rounded-xl border border-[#E4E8E4] focus:outline-none focus:border-[#1F5F5B]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#0F1F2E] mb-1">
                    Asset / Instrument Type
                  </label>
                  <select
                    value={formData.type}
                    onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                    className="w-full px-3.5 py-2 text-xs rounded-xl border border-[#E4E8E4] focus:outline-none focus:border-[#1F5F5B] bg-white"
                  >
                    <option value="EQUITY">EQUITY</option>
                    <option value="MUTUAL_FUND">MUTUAL_FUND</option>
                    <option value="SCHEME">ADVISORY_SCHEME</option>
                    <option value="CRYPTO">CRYPTO</option>
                    <option value="FOREX">FOREX</option>
                    <option value="OTHER">OTHER</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#0F1F2E] mb-1">
                    Return / Payout Received (₹, if any)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.returnAmount}
                    onChange={(e) => setFormData({ ...formData, returnAmount: e.target.value })}
                    placeholder="e.g. 24000 (if payout occurred)"
                    className="w-full px-3.5 py-2 text-xs rounded-xl border border-[#E4E8E4] focus:outline-none focus:border-[#1F5F5B]"
                  />
                  <p className="text-[10px] text-[#5B6B7A] mt-0.5">
                    Crucial for detecting "return-followed-by-escalation" grooming sequences.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#0F1F2E] mb-1">
                    Status
                  </label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                    className="w-full px-3.5 py-2 text-xs rounded-xl border border-[#E4E8E4] focus:outline-none focus:border-[#1F5F5B] bg-white"
                  >
                    <option value="ACTIVE">ACTIVE</option>
                    <option value="RETURNED">RETURNED</option>
                    <option value="CLOSED">CLOSED</option>
                  </select>
                </div>
              </form>
            </div>

            <div className="pt-6 border-t border-[#E4E8E4] flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setDrawerOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold border border-[#E4E8E4] text-[#0F1F2E] hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                form="drawerForm"
                className="px-5 py-2 rounded-xl text-xs font-bold bg-[#1F5F5B] text-white hover:bg-[#2A7A74]"
              >
                Save Investment
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CSV Drag & Drop / Upload Modal */}
      {csvModalOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-xl bg-white rounded-2xl shadow-2xl p-6 space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-[#E4E8E4]">
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="w-5 h-5 text-[#1F5F5B]" />
                <h3 className="font-heading font-extrabold text-base text-[#0F1F2E]">
                  Import Investments from CSV
                </h3>
              </div>
              <button
                onClick={() => setCsvModalOpen(false)}
                className="p-1 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-[#5B6B7A]">
              Upload a standard CSV file with headers: <code className="bg-gray-100 px-1 py-0.5 rounded text-[11px]">entity_name, amount, invested_on, type, return_amount, status</code>.
            </p>

            <div className="border-2 border-dashed border-[#E4E8E4] rounded-2xl p-6 text-center hover:border-[#1F5F5B] transition-colors bg-[#F5F6F3]">
              <input
                type="file"
                accept=".csv"
                id="csvInput"
                onChange={handleFileChange}
                className="hidden"
              />
              <label htmlFor="csvInput" className="cursor-pointer flex flex-col items-center gap-2">
                <Upload className="w-8 h-8 text-[#1F5F5B]" />
                <span className="text-xs font-bold text-[#0F1F2E]">
                  {csvFile ? csvFile.name : 'Click to select or drag CSV file here'}
                </span>
                <span className="text-[11px] text-[#5B6B7A]">
                  Supports comma-delimited UTF-8 files
                </span>
              </label>
            </div>

            {/* Preview table */}
            {csvPreview.length > 0 && (
              <div className="space-y-1.5">
                <div className="text-[11px] font-bold text-[#5B6B7A] uppercase">Preview (first rows):</div>
                <div className="bg-gray-50 border border-[#E4E8E4] rounded-xl p-2 max-h-32 overflow-y-auto text-[10px] font-mono text-[#0F1F2E]">
                  {csvPreview.map((row, idx) => (
                    <div key={idx} className="truncate">
                      {row.join(' | ')}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Error or Success Report */}
            {csvResult && (
              <div className={`p-4 rounded-xl text-xs ${csvResult.failedCount > 0 ? 'bg-amber-50 border border-amber-200 text-amber-800' : 'bg-green-50 border border-green-200 text-green-800'}`}>
                <div className="font-bold mb-1 flex items-center gap-1.5">
                  {csvResult.failedCount > 0 ? <AlertCircle className="w-4 h-4 text-amber-600" /> : <CheckCircle2 className="w-4 h-4 text-green-600" />}
                  Import Finished: {csvResult.importedCount} valid events imported.
                </div>
                {csvResult.errors.length > 0 && (
                  <div className="mt-2 space-y-1">
                    <div className="font-semibold text-red-700">Row-level issues ({csvResult.failedCount}):</div>
                    <ul className="list-disc pl-4 text-[11px] text-red-600 max-h-24 overflow-y-auto">
                      {csvResult.errors.map((err, i) => (
                        <li key={i}>{err}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setCsvModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold border border-[#E4E8E4] text-[#0F1F2E] hover:bg-gray-50"
              >
                Close
              </button>
              <button
                onClick={handleCsvUpload}
                disabled={!csvFile || csvUploading}
                className="px-5 py-2 rounded-xl text-xs font-bold bg-[#1F5F5B] text-white hover:bg-[#2A7A74] disabled:opacity-50"
              >
                {csvUploading ? 'Processing...' : 'Upload & Parse CSV'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default InvestmentsPage;
