package com.fingaurd.model;

public enum InvestmentStatus {
    ACTIVE,
    RETURNED,
    CLOSED
}
