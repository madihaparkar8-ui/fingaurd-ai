import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { investmentService, riskService, journeyService } from '../services/api';
import { Investment, Journey } from '../types';
import { formatINR } from '../utils/formatters';
import {
  ShieldAlert, Sparkles, MessageSquareWarning,
  CheckSquare, ArrowRight, Loader2, Info
} from 'lucide-react';

export const AnalysePage: React.FC = () => {
  const navigate = useNavigate();

  const [investments, setInvestments] = useState<Investment[]>([]);
  const [journey, setJourney] = useState<Journey | null>(null);

  const [amount, setAmount] = useState('400000');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [entity, setEntity] = useState('Apex Wealth Advisory');
  const [communicationText, setCommunicationText] = useState('');
  const [consentGranted, setConsentGranted] = useState(true);

  const [loading, setLoading] = useState(false);
  const [analysing, setAnalysing] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [invs, j] = await Promise.all([
          investmentService.getAll().catch(() => []),
          journeyService.getMyJourney().catch(() => null),
        ]);
        setInvestments(invs);
        setJourney(j);
        if (invs.length > 0 && !entity) {
          setEntity(invs[0].entityName);
        }
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const historicalMax = journey?.maxSingleCommitment || 100000;
  const numAmount = parseFloat(amount) || 0;
  const liveRatio = historicalMax > 0 ? (numAmount / historicalMax).toFixed(1) : '1.0';

  const handlePasteSampleCommunication = () => {
    setCommunicationText(
      "Congratulations on your previous returns! Our VIP group quota is closing in next 2 hours. This is your last chance today. Special guaranteed 35% assured returns from our SEBI registered guru. Transfer ₹4,00,000 immediately to lock your VIP slot. Limited slots only 3 left! To release your withdrawal fast, deposit the full amount now!"
    );
    setConsentGranted(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!numAmount || !entity || !date) return;

    try {
      setAnalysing(true);
      const res = await riskService.analyse({
        amount: numAmount,
        date,
        entity,
        communicationText: communicationText.trim() ? communicationText : undefined,
        consentGranted: communicationText.trim() ? consentGranted : false,
      });

      // Route immediately to the generated Risk Report
      navigate(`/reports?id=${res.reportId}`);
    } catch (err: any) {
      alert(err?.response?.data?.message || 'Failed to complete risk analysis');
    } finally {
      setAnalysing(false);
    }
  };

  const uniqueEntities = Array.from(new Set(investments.map((i) => i.entityName)));

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-heading font-black tracking-tight text-[#0F1F2E] flex items-center gap-2">
          <ShieldAlert className="w-6 h-6 text-[#1F5F5B]" />
          Pre-Commitment Risk Check
        </h1>
        <p className="text-xs text-[#5B6B7A]">
          Evaluate a proposed commitment against your personal baseline journey before capital transfer.
        </p>
      </div>

      <div className="bg-white p-6 sm:p-8 rounded-fin border border-[#E4E8E4] shadow-fin-card">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Amount Input with Live Multiplier Badge */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold text-[#0F1F2E]">
                Proposed Commitment Amount (₹) *
              </label>
              {numAmount > 0 && historicalMax > 0 && (
                <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                  parseFloat(liveRatio) >= 2.0
                    ? 'bg-[#FBE9E0] text-[#D9784A]'
                    : 'bg-[#E3F0EE] text-[#1F5F5B]'
                }`}>
                  {liveRatio}× historical max ({formatINR(historicalMax)})
                </span>
              )}
            </div>
            <input
              type="number"
              step="1"
              min="1"
              required
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="e.g. 400000"
              className="w-full px-4 py-3 text-lg font-bold font-tabular rounded-xl border border-[#E4E8E4] focus:outline-none focus:border-[#1F5F5B] text-[#0F1F2E]"
            />
            <p className="text-[11px] text-[#5B6B7A] mt-1">
              Entering the exact amount allows the engine to compute baseline z-score and velocity.
            </p>
          </div>

          {/* Date and Entity Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#0F1F2E] mb-1">
                Planned Date of Commitment *
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-[#E4E8E4] focus:outline-none focus:border-[#1F5F5B] text-[#0F1F2E]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#0F1F2E] mb-1">
                Recipient Entity / Advisory *
              </label>
              <input
                type="text"
                list="entity-suggestions"
                required
                value={entity}
                onChange={(e) => setEntity(e.target.value)}
                placeholder="Entity name"
                className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-[#E4E8E4] focus:outline-none focus:border-[#1F5F5B] text-[#0F1F2E]"
              />
              <datalist id="entity-suggestions">
                {uniqueEntities.map((ent, idx) => (
                  <option key={idx} value={ent} />
                ))}
              </datalist>
            </div>
          </div>

          {/* Optional Communication Influence Analysis */}
          <div className="p-5 rounded-2xl bg-[#F5F6F3] border border-[#E4E8E4] space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MessageSquareWarning className="w-4 h-4 text-[#1F5F5B]" />
                <span className="text-xs font-bold text-[#0F1F2E]">
                  Optional Communication Text
                </span>
              </div>
              <button
                type="button"
                onClick={handlePasteSampleCommunication}
                className="text-[11px] font-bold text-[#1F5F5B] hover:underline flex items-center gap-1"
              >
                <Sparkles className="w-3 h-3 text-[#C9A24A]" />
                Paste Sample Pressure Text
              </button>
            </div>

            <textarea
              rows={4}
              value={communicationText}
              onChange={(e) => setCommunicationText(e.target.value)}
              placeholder="Paste WhatsApp message, Telegram instruction, or email received from the advisor/firm..."
              className="w-full p-3 text-xs rounded-xl border border-[#E4E8E4] focus:outline-none focus:border-[#1F5F5B] bg-white text-[#0F1F2E]"
            />

            {/* Explicit Consent Checkbox */}
            <label className="flex items-start gap-2.5 cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={consentGranted}
                onChange={(e) => setConsentGranted(e.target.checked)}
                className="mt-0.5 rounded text-[#1F5F5B] focus:ring-[#1F5F5B] accent-[#1F5F5B]"
              />
              <div className="text-[11px] text-[#5B6B7A] leading-tight">
                <strong className="text-[#0F1F2E]">Explicit Consent:</strong> I consent to rule-based keyword & pattern analysis on this communication snippet strictly for manipulation heuristic indicators. No message is stored with personal sender identifiers.
              </div>
            </label>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={analysing}
            className="w-full py-3.5 px-6 rounded-xl text-xs font-bold bg-[#1F5F5B] text-white hover:bg-[#2A7A74] transition-all flex items-center justify-center gap-2 shadow-fin-hover"
          >
            {analysing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-[#C9A24A]" />
                <span>Analysing Journey, Historical Deviation & Heuristics...</span>
              </>
            ) : (
              <>
                <span>Run Pre-Commitment Risk Analysis</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>
      </div>

      <div className="p-4 rounded-xl bg-white border border-[#E4E8E4] flex items-center gap-2.5 text-xs text-[#5B6B7A]">
        <Info className="w-4 h-4 text-[#1F5F5B] flex-shrink-0" />
        <span>
          <strong>Prototype score — not validated.</strong> This analysis is intended to provide behavioural pre-commitment clarity and does not constitute financial advice or an accusation of fraud.
        </span>
      </div>
    </div>
  );
};

export default AnalysePage;
