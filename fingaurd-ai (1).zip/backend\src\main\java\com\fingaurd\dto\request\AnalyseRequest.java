package com.fingaurd.dto.request;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;

public class AnalyseRequest {

    @NotNull(message = "Proposed amount is required")
    @DecimalMin(value = "0.01", message = "Amount must be positive")
    private BigDecimal amount;

    @NotNull(message = "Proposed date is required")
    private LocalDate date;

    @NotBlank(message = "Target entity name is required")
    private String entity;

    private String communicationText;

    private Boolean consentGranted = false;

    public AnalyseRequest() {}

    public AnalyseRequest(BigDecimal amount, LocalDate date, String entity, String communicationText, Boolean consentGranted) {
        this.amount = amount;
        this.date = date;
        this.entity = entity;
        this.communicationText = communicationText;
        this.consentGranted = consentGranted != null ? consentGranted : false;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getEntity() {
        return entity;
    }

    public void setEntity(String entity) {
        this.entity = entity;
    }

    public String getCommunicationText() {
        return communicationText;
    }

    public void setCommunicationText(String communicationText) {
        this.communicationText = communicationText;
    }

    public Boolean getConsentGranted() {
        return consentGranted;
    }

    public void setConsentGranted(Boolean consentGranted) {
        this.consentGranted = consentGranted;
    }
}
