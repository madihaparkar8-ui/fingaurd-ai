package com.fingaurd.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "risk_reports", indexes = {
    @Index(name = "idx_report_journey_id", columnList = "journey_id"),
    @Index(name = "idx_report_created_at", columnList = "created_at")
})
public class RiskReport {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "report_id")
    private Long reportId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "journey_id", nullable = false)
    @JsonIgnore
    private Journey journey;

    @Column(name = "target_investment", precision = 15, scale = 2, nullable = false)
    private BigDecimal targetInvestment;

    @Column(name = "target_entity", nullable = false, length = 150)
    private String targetEntity;

    @Lob
    @Column(name = "component_scores", columnDefinition = "TEXT")
    private String componentScores; // JSON representation of components

    @Column(name = "anomaly_score")
    private Double anomalyScore;

    @Column(name = "overall_score", nullable = false)
    private Integer overallScore;

    @Column(name = "risk_level", nullable = false, length = 30)
    private String riskLevel; // LOW, MODERATE, HIGH, CRITICAL

    @Column(name = "communication_used", nullable = false)
    private Boolean communicationUsed = false;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @OneToMany(mappedBy = "riskReport", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<RiskSignal> riskSignals = new ArrayList<>();

    public RiskReport() {
    }

    public RiskReport(Journey journey, BigDecimal targetInvestment, String targetEntity, String componentScores,
                      Double anomalyScore, Integer overallScore, String riskLevel, Boolean communicationUsed) {
        this.journey = journey;
        this.targetInvestment = targetInvestment;
        this.targetEntity = targetEntity;
        this.componentScores = componentScores;
        this.anomalyScore = anomalyScore;
        this.overallScore = overallScore;
        this.riskLevel = riskLevel;
        this.communicationUsed = communicationUsed != null ? communicationUsed : false;
    }

    @PrePersist
    protected void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }

    public Long getReportId() {
        return reportId;
    }

    public void setReportId(Long reportId) {
        this.reportId = reportId;
    }

    public Journey getJourney() {
        return journey;
    }

    public void setJourney(Journey journey) {
        this.journey = journey;
    }

    public Long getJourneyId() {
        return journey != null ? journey.getJourneyId() : null;
    }

    public BigDecimal getTargetInvestment() {
        return targetInvestment;
    }

    public void setTargetInvestment(BigDecimal targetInvestment) {
        this.targetInvestment = targetInvestment;
    }

    public String getTargetEntity() {
        return targetEntity;
    }

    public void setTargetEntity(String targetEntity) {
        this.targetEntity = targetEntity;
    }

    public String getComponentScores() {
        return componentScores;
    }

    public void setComponentScores(String componentScores) {
        this.componentScores = componentScores;
    }

    public Double getAnomalyScore() {
        return anomalyScore;
    }

    public void setAnomalyScore(Double anomalyScore) {
        this.anomalyScore = anomalyScore;
    }

    public Integer getOverallScore() {
        return overallScore;
    }

    public void setOverallScore(Integer overallScore) {
        this.overallScore = overallScore;
    }

    public String getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(String riskLevel) {
        this.riskLevel = riskLevel;
    }

    public Boolean getCommunicationUsed() {
        return communicationUsed;
    }

    public void setCommunicationUsed(Boolean communicationUsed) {
        this.communicationUsed = communicationUsed;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public List<RiskSignal> getRiskSignals() {
        return riskSignals;
    }

    public void setRiskSignals(List<RiskSignal> riskSignals) {
        this.riskSignals = riskSignals;
    }

    public void addSignal(RiskSignal signal) {
        this.riskSignals.add(signal);
        signal.setRiskReport(this);
    }
}
