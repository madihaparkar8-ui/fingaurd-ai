package com.fingaurd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FingaurdApplication {

    public static void main(String[] args) {
        SpringApplication.run(FingaurdApplication.class, args);
    }
}
