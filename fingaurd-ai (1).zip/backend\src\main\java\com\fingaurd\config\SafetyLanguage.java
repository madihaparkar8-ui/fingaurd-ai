package com.fingaurd.config;

import java.util.List;

public final class SafetyLanguage {

    private SafetyLanguage() {}

    public static final String DISCLAIMER = "Prototype score — not validated. This is not financial advice and not a fraud verdict.";

    public static final String HIGH_RISK_PATTERN = "High-risk behavioural pattern";
    public static final String MANIPULATION_INDICATORS = "Manipulation indicators detected";
    public static final String UNUSUAL_COMMITMENT = "This commitment is unusual relative to your history";
    public static final String PAUSE_AND_VERIFY = "Pause and independently verify before committing";

    public static final List<String> PROHIBITED_PHRASES = List.of(
        "Fraud Detected",
        "Guaranteed Scam",
        "You will lose money",
        "This is a scam"
    );

    public static void validateNoProhibitedLanguage(String text) {
        if (text == null) return;
        String lower = text.toLowerCase();
        for (String prohibited : PROHIBITED_PHRASES) {
            if (lower.contains(prohibited.toLowerCase())) {
                throw new IllegalStateException("Violation of Consumer-Safety Language Policy: prohibited phrase '" + prohibited + "' found.");
            }
        }
    }
}
