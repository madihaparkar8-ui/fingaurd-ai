import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Logo } from '../components/Logo';
import { Sparkles, ArrowRight, AlertCircle } from 'lucide-react';

export const RegisterPage: React.FC = () => {
  const { register, loginAsDemo } = useAuth();
  const navigate = useNavigate();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [demoLoading, setDemoLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      await register(name, email, password);
      navigate('/dashboard');
    } catch (err: any) {
      setError(err?.response?.data?.message || 'Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleDemoLogin = async () => {
    setError(null);
    setDemoLoading(true);
    try {
      await loginAsDemo();
      navigate('/dashboard');
    } catch (err: any) {
      setError(err?.response?.data?.message || 'Demo login failed.');
    } finally {
      setDemoLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F6F3] flex flex-col justify-center py-12 px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <Link to="/" className="inline-block mb-6">
          <Logo size="lg" showTagline={true} />
        </Link>
        <h2 className="text-2xl font-heading font-extrabold text-[#0F1F2E]">
          Create your account
        </h2>
        <p className="mt-1 text-xs text-[#5B6B7A]">
          Begin monitoring your pre-commitment decision journeys
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-6 sm:px-10 shadow-fin-card rounded-fin border border-[#E4E8E4] space-y-6">
          <div className="p-4 rounded-xl bg-[#E3F0EE] border border-[#BCE1DB] flex flex-col gap-2">
            <div className="flex items-center gap-2 text-xs font-bold text-[#1F5F5B]">
              <Sparkles className="w-4 h-4 text-[#C9A24A]" />
              Quick Academic Evaluator Access
            </div>
            <p className="text-[11px] text-[#5B6B7A]">
              Skip manual registration to access the live demo account immediately.
            </p>
            <button
              type="button"
              onClick={handleDemoLogin}
              disabled={demoLoading}
              className="w-full mt-1 py-2 px-3 rounded-lg text-xs font-bold bg-[#1F5F5B] text-white hover:bg-[#2A7A74] transition-all flex items-center justify-center gap-1.5 shadow-2xs"
            >
              <span>{demoLoading ? 'Authenticating...' : 'Use Demo Account (One Click)'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-[#E4E8E4]" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-white px-3 text-[#5B6B7A] font-semibold text-[10px]">Or register with details</span>
            </div>
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-[#0F1F2E] mb-1">
                Full Name
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Priya Verma"
                className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-[#E4E8E4] focus:outline-none focus:border-[#1F5F5B] focus:ring-1 focus:ring-[#1F5F5B] bg-white text-[#0F1F2E]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#0F1F2E] mb-1">
                Email address
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="priya@example.com"
                className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-[#E4E8E4] focus:outline-none focus:border-[#1F5F5B] focus:ring-1 focus:ring-[#1F5F5B] bg-white text-[#0F1F2E]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#0F1F2E] mb-1">
                Password
              </label>
              <input
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Minimum 6 characters"
                className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-[#E4E8E4] focus:outline-none focus:border-[#1F5F5B] focus:ring-1 focus:ring-[#1F5F5B] bg-white text-[#0F1F2E]"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 px-4 rounded-xl text-xs font-bold text-white bg-[#0F1F2E] hover:bg-[#1E2D3D] transition-colors shadow-2xs"
            >
              {loading ? 'Registering Account...' : 'Create Account'}
            </button>
          </form>

          <div className="text-center text-xs text-[#5B6B7A]">
            Already have an account?{' '}
            <Link to="/login" className="font-semibold text-[#1F5F5B] hover:underline">
              Sign in
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;
