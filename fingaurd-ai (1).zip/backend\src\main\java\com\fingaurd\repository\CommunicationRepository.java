package com.fingaurd.repository;

import com.fingaurd.model.Communication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface CommunicationRepository extends JpaRepository<Communication, Long> {
    List<Communication> findByUser_UserIdOrderByTimestampDesc(Long userId);
    void deleteByUser_UserId(Long userId);
}
