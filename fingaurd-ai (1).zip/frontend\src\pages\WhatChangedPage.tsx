import React, { useEffect, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { riskService } from '../services/api';
import { GroupedSignals, RiskReport } from '../types';
import {
  GitCommit, AlertTriangle, ShieldCheck,
  ArrowRight, ExternalLink, ArrowLeft, Brain, Lightbulb
} from 'lucide-react';

export const WhatChangedPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const reportIdParam = searchParams.get('id');

  const [signals, setSignals] = useState<GroupedSignals | null>(null);
  const [report, setReport] = useState<RiskReport | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        let repId = reportIdParam ? Number(reportIdParam) : null;
        if (!repId) {
          const history = await riskService.getHistory();
          if (history.length > 0) {
            repId = history[0].reportId;
          }
        }

        if (repId) {
          const [sData, rData] = await Promise.all([
            riskService.getSignals(repId),
            riskService.getReport(repId),
          ]);
          setSignals(sData);
          setReport(rData);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [reportIdParam]);

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-10 bg-gray-200 rounded-xl w-64" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="h-96 bg-gray-200 rounded-2xl" />
          <div className="h-96 bg-gray-200 rounded-2xl" />
          <div className="h-96 bg-gray-200 rounded-2xl" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <Link
            to={report ? `/reports?id=${report.reportId}` : '/reports'}
            className="text-xs font-semibold text-[#1F5F5B] hover:underline flex items-center gap-1 mb-1"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Back to Risk Report
          </Link>
          <h1 className="text-2xl font-heading font-black tracking-tight text-[#0F1F2E]">
            Explainable Behavioral Breakdown
          </h1>
          <p className="text-xs text-[#5B6B7A]">
            Transparent 3-column decomposition of signals, reasons, and independent verification actions.
          </p>
        </div>

        {report && (
          <Link
            to={`/pause?id=${report.reportId}`}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-[#B4414B] text-white hover:bg-[#9B333C] flex items-center gap-1.5 shadow-2xs self-start sm:self-auto"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Open Pause Intervention</span>
          </Link>
        )}
      </div>

      {/* 3 Clean Columns */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
        {/* Column 1: What Changed? */}
        <div className="bg-white p-6 rounded-fin border border-[#E4E8E4] shadow-fin-card space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-[#E4E8E4]">
            <div className="w-7 h-7 rounded-lg bg-[#E3F0EE] text-[#1F5F5B] flex items-center justify-center">
              <GitCommit className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-heading font-extrabold text-sm text-[#0F1F2E]">What Changed?</h3>
              <p className="text-[11px] text-[#5B6B7A]">Structural metrics that deviated</p>
            </div>
          </div>

          <div className="space-y-3">
            {signals?.whatChanged && signals.whatChanged.length > 0 ? (
              signals.whatChanged.map((sig, idx) => (
                <div key={idx} className="p-3.5 rounded-xl bg-[#F5F6F3] border border-[#E4E8E4] space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-[#0F1F2E]">{sig.type}</span>
                    <span className="font-bold text-[#1F5F5B] font-tabular">{sig.value}</span>
                  </div>
                  <p className="text-[11px] text-[#5B6B7A] leading-relaxed">{sig.explanation}</p>
                  {sig.sourceEvent && (
                    <div className="pt-1 text-[10px] text-gray-400">
                      Linked to historical event #{sig.sourceEvent}
                    </div>
                  )}
                </div>
              ))
            ) : (
              <div className="p-6 text-center text-xs text-[#5B6B7A]">
                No significant statistical changes found in this proposal.
              </div>
            )}
          </div>
        </div>

        {/* Column 2: Why Does It Matter? */}
        <div className="bg-white p-6 rounded-fin border border-[#E4E8E4] shadow-fin-card space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-[#E4E8E4]">
            <div className="w-7 h-7 rounded-lg bg-[#FBE9E0] text-[#D9784A] flex items-center justify-center">
              <AlertTriangle className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-heading font-extrabold text-sm text-[#0F1F2E]">Why It Matters?</h3>
              <p className="text-[11px] text-[#5B6B7A]">Psychological & sequence risk factors</p>
            </div>
          </div>

          <div className="space-y-3">
            {signals?.whyItMatters && signals.whyItMatters.length > 0 ? (
              signals.whyItMatters.map((sig, idx) => (
                <div key={idx} className="p-3.5 rounded-xl bg-[#FBE9E0]/40 border border-[#F0BC9F]/50 space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-[#0F1F2E]">{sig.type}</span>
                    <span className="font-bold text-[#D9784A] font-tabular">{sig.value}</span>
                  </div>
                  <p className="text-[11px] text-[#5B6B7A] leading-relaxed">{sig.explanation}</p>
                </div>
              ))
            ) : (
              <div className="p-6 text-center text-xs text-[#5B6B7A]">
                No high-risk grooming sequences or coercion patterns identified.
              </div>
            )}
          </div>
        </div>

        {/* Column 3: What Can I Verify? */}
        <div className="bg-white p-6 rounded-fin border border-[#E4E8E4] shadow-fin-card space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-[#E4E8E4]">
            <div className="w-7 h-7 rounded-lg bg-[#E6F2EA] text-[#5FA37A] flex items-center justify-center">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-heading font-extrabold text-sm text-[#0F1F2E]">What Can I Verify?</h3>
              <p className="text-[11px] text-[#5B6B7A]">Independent regulatory checkpoints</p>
            </div>
          </div>

          <div className="space-y-3">
            {signals?.whatCanIVerify && signals.whatCanIVerify.map((sig, idx) => (
              <div key={idx} className="p-3.5 rounded-xl bg-[#E6F2EA]/40 border border-[#A4D1B5]/50 space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-[#0F1F2E]">{sig.value}</span>
                  <ExternalLink className="w-3.5 h-3.5 text-[#5FA37A]" />
                </div>
                <p className="text-[11px] text-[#5B6B7A] leading-relaxed">{sig.explanation}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Behavioural Biases & Psychological Mechanisms Section */}
      {report?.behaviouralBiases && report.behaviouralBiases.length > 0 && (
        <div className="bg-white p-6 rounded-fin border border-[#E4E8E4] shadow-fin-card space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#E4E8E4]">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-[#E3F0EE] text-[#1F5F5B] flex items-center justify-center">
                <Brain className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-heading font-extrabold text-sm text-[#0F1F2E]">
                  Cognitive Biases & Psychological Traps
                </h3>
                <p className="text-[11px] text-[#5B6B7A]">
                  How structural deviations translate into mental vulnerability and manipulation
                </p>
              </div>
            </div>
            <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-[#FBE9E0] text-[#D9784A] border border-[#F0BC9F]">
              {report.behaviouralBiases.length} Cognitive Risk Factors
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {report.behaviouralBiases.map((bias, idx) => (
              <div key={idx} className="p-4 rounded-xl bg-[#F5F6F3] border border-[#E4E8E4] space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-heading font-bold text-xs sm:text-sm text-[#0F1F2E]">
                    {bias.title}
                  </h4>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    bias.severity === 'HIGH' ? 'bg-[#FBE9E0] text-[#B4414B]' : 'bg-[#FBF1DB] text-[#D9A441]'
                  }`}>
                    {bias.severity}
                  </span>
                </div>
                <p className="text-[11px] text-[#5B6B7A]">
                  <strong className="text-[#0F1F2E]">Psychology: </strong>{bias.psychologicalMechanism}
                </p>
                <div className="p-2.5 rounded-lg bg-white border border-[#E4E8E4] text-[11px] text-[#1F5F5B] flex items-start gap-1.5">
                  <Lightbulb className="w-3.5 h-3.5 text-[#C9A24A] flex-shrink-0 mt-0.5" />
                  <span><strong>Countermeasure: </strong>{bias.actionableCountermeasure}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default WhatChangedPage;
