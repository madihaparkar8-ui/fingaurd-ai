package com.fingaurd.dto.response;

import com.fingaurd.model.InvestmentStatus;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class JourneyEventResponse {

    private Long investmentId;
    private String entityName;
    private BigDecimal amount;
    private LocalDate investedOn;
    private String type;
    private BigDecimal returnAmount;
    private InvestmentStatus status;
    private Double stepRatio;
    private List<String> badges = new ArrayList<>();

    public JourneyEventResponse() {}

    public Long getInvestmentId() {
        return investmentId;
    }

    public void setInvestmentId(Long investmentId) {
        this.investmentId = investmentId;
    }

    public String getEntityName() {
        return entityName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public LocalDate getInvestedOn() {
        return investedOn;
    }

    public void setInvestedOn(LocalDate investedOn) {
        this.investedOn = investedOn;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public BigDecimal getReturnAmount() {
        return returnAmount;
    }

    public void setReturnAmount(BigDecimal returnAmount) {
        this.returnAmount = returnAmount;
    }

    public InvestmentStatus getStatus() {
        return status;
    }

    public void setStatus(InvestmentStatus status) {
        this.status = status;
    }

    public Double getStepRatio() {
        return stepRatio;
    }

    public void setStepRatio(Double stepRatio) {
        this.stepRatio = stepRatio;
    }

    public List<String> getBadges() {
        return badges;
    }

    public void setBadges(List<String> badges) {
        this.badges = badges;
    }

    public void addBadge(String badge) {
        this.badges.add(badge);
    }
}
