package com.fingaurd.repository;

import com.fingaurd.model.RiskReport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface RiskReportRepository extends JpaRepository<RiskReport, Long> {
    List<RiskReport> findByJourney_User_UserIdOrderByCreatedAtDesc(Long userId);
    Optional<RiskReport> findTopByJourney_User_UserIdOrderByCreatedAtDesc(Long userId);
    Optional<RiskReport> findByReportIdAndJourney_User_UserId(Long reportId, Long userId);
}
