package com.fingaurd.dto.request;

import com.fingaurd.model.InvestmentStatus;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;

public class InvestmentRequest {

    @NotBlank(message = "Entity name cannot be empty")
    private String entityName;

    @NotNull(message = "Amount is required")
    @DecimalMin(value = "0.01", message = "Amount must be positive")
    private BigDecimal amount;

    @NotNull(message = "Investment date is required")
    private LocalDate investedOn;

    private String type = "EQUITY";

    private BigDecimal returnAmount;

    private InvestmentStatus status = InvestmentStatus.ACTIVE;

    public InvestmentRequest() {}

    public InvestmentRequest(String entityName, BigDecimal amount, LocalDate investedOn, String type, BigDecimal returnAmount, InvestmentStatus status) {
        this.entityName = entityName;
        this.amount = amount;
        this.investedOn = investedOn;
        this.type = type != null ? type : "EQUITY";
        this.returnAmount = returnAmount;
        this.status = status != null ? status : InvestmentStatus.ACTIVE;
    }

    public String getEntityName() {
        return entityName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public LocalDate getInvestedOn() {
        return investedOn;
    }

    public void setInvestedOn(LocalDate investedOn) {
        this.investedOn = investedOn;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public BigDecimal getReturnAmount() {
        return returnAmount;
    }

    public void setReturnAmount(BigDecimal returnAmount) {
        this.returnAmount = returnAmount;
    }

    public InvestmentStatus getStatus() {
        return status;
    }

    public void setStatus(InvestmentStatus status) {
        this.status = status;
    }
}
