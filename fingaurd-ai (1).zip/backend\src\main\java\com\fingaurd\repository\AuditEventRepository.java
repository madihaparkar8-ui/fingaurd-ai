package com.fingaurd.repository;

import com.fingaurd.model.AuditEvent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface AuditEventRepository extends JpaRepository<AuditEvent, Long> {
    List<AuditEvent> findByUser_UserIdOrderByTimestampDesc(Long userId);
    List<AuditEvent> findTop50ByUser_UserIdOrderByTimestampDesc(Long userId);
}
