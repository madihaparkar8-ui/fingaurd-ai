import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { RiskGauge } from '../components/RiskGauge';
import { ShieldAlert, ArrowRight, Milestone, Sparkles, Scale, Lock, Eye, CheckCircle2 } from 'lucide-react';

export const LandingPage: React.FC = () => {
  const { loginAsDemo } = useAuth();
  const navigate = useNavigate();
  const [demoGaugeScore, setDemoGaugeScore] = useState(73);
  const [loadingDemo, setLoadingDemo] = useState(false);

  const handleDemoClick = async () => {
    try {
      setLoadingDemo(true);
      await loginAsDemo();
      navigate('/dashboard');
    } catch (err) {
      console.error(err);
      navigate('/login');
    } finally {
      setLoadingDemo(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F6F3] text-[#0F1F2E]">
      {/* Top Floating Glass Navigation */}
      <header className="sticky top-0 z-50 bg-[#F5F6F3]/80 backdrop-blur-md border-b border-[#E4E8E4] px-6 lg:px-12 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#1F5F5B] text-white flex items-center justify-center font-bold text-base shadow-sm">
              F
            </div>
            <span className="font-heading font-extrabold text-xl tracking-tight text-[#0F1F2E]">
              Fingaurd <span className="text-[#1F5F5B]">AI</span>
            </span>
          </div>
          <div className="flex items-center gap-4">
            <Link to="/login" className="text-xs font-semibold text-[#5B6B7A] hover:text-[#0F1F2E] transition-colors">
              Sign In
            </Link>
            <button
              onClick={handleDemoClick}
              disabled={loadingDemo}
              className="px-4 py-2 text-xs font-bold rounded-lg bg-[#1F5F5B] text-white hover:bg-[#2A7A74] transition-all shadow-sm flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#C9A24A]" />
              {loadingDemo ? 'Launching...' : 'Try the Demo'}
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="px-6 lg:px-12 pt-16 pb-20 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#E3F0EE] text-[#1F5F5B] text-xs font-bold tracking-wide">
              <ShieldAlert className="w-4 h-4" />
              Pre-Commitment Risk Intelligence Platform
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-heading font-black tracking-tight leading-[1.1] text-[#0F1F2E]">
              Pause before <br />
              <span className="text-[#1F5F5B]">you commit.</span>
            </h1>

            <p className="text-base sm:text-lg text-[#5B6B7A] leading-relaxed max-w-xl">
              Investment manipulation in India is rarely one bad payment. It is a journey: a small first investment, an apparent return, then escalating commitments until a major trap. Fingaurd AI intervenes before you transfer.
            </p>

            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={handleDemoClick}
                disabled={loadingDemo}
                className="px-6 py-3.5 rounded-xl font-bold text-sm bg-[#1F5F5B] text-white hover:bg-[#2A7A74] transition-all shadow-fin-hover flex items-center gap-2"
              >
                <span>{loadingDemo ? 'Preparing Workspace...' : 'Try Interactive Demo'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <Link
                to="/register"
                className="px-6 py-3.5 rounded-xl font-semibold text-sm bg-white border border-[#E4E8E4] text-[#0F1F2E] hover:bg-gray-50 transition-colors shadow-2xs"
              >
                Create Free Account
              </Link>
            </div>

            <div className="pt-4 flex items-center gap-6 text-xs text-[#5B6B7A]">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#5FA37A]" />
                Zero bank or UPI access
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#5FA37A]" />
                Explainable Signals
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#5FA37A]" />
                Strict Safe Language
              </div>
            </div>
          </div>

          {/* Interactive Hero Gauge Preview */}
          <div className="lg:col-span-5 bg-white p-8 rounded-fin border border-[#E4E8E4] shadow-fin-card flex flex-col items-center relative overflow-hidden">
            <div className="w-full flex items-center justify-between pb-4 border-b border-[#E4E8E4] mb-4">
              <span className="text-xs font-bold text-[#5B6B7A] uppercase tracking-wider">Live Simulation</span>
              <span className="text-[11px] font-medium px-2 py-0.5 rounded bg-[#E3F0EE] text-[#1F5F5B]">Golden Scenario</span>
            </div>

            <RiskGauge score={demoGaugeScore} size={300} animate={true} />

            {/* Slider to interactively test gauge bands */}
            <div className="w-full mt-6 pt-4 border-t border-[#E4E8E4] space-y-2">
              <div className="flex justify-between text-xs text-[#5B6B7A]">
                <span>Simulate Index Slider:</span>
                <span className="font-bold text-[#0F1F2E] font-tabular">{demoGaugeScore} / 100</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={demoGaugeScore}
                onChange={(e) => setDemoGaugeScore(Number(e.target.value))}
                className="w-full accent-[#1F5F5B] cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-gray-400 font-semibold uppercase">
                <span>Low (0-25)</span>
                <span>Mod (26-50)</span>
                <span>High (51-75)</span>
                <span>Crit (76-100)</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3 Core Value Cards */}
      <section className="px-6 lg:px-12 py-16 bg-white border-y border-[#E4E8E4]">
        <div className="max-w-7xl mx-auto space-y-12">
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <h2 className="text-3xl font-heading font-extrabold tracking-tight text-[#0F1F2E]">
              Core Principles Built for Pre-Commitment Safety
            </h2>
            <p className="text-sm text-[#5B6B7A]">
              Standard fraud filters look at transactions in isolation. Fingaurd AI reconstructs the psychological sequence of escalation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 rounded-2xl bg-[#F5F6F3] border border-[#E4E8E4] space-y-3">
              <div className="w-10 h-10 rounded-xl bg-[#E3F0EE] text-[#1F5F5B] flex items-center justify-center">
                <Milestone className="w-5 h-5" />
              </div>
              <h3 className="font-heading font-bold text-lg text-[#0F1F2E]">Journey Replay</h3>
              <p className="text-xs text-[#5B6B7A] leading-relaxed">
                Reconstructs the full sequence of commitments over time, tagging behavioral transitions such as positive returns immediately followed by 4× step-ups.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#F5F6F3] border border-[#E4E8E4] space-y-3">
              <div className="w-10 h-10 rounded-xl bg-[#E3F0EE] text-[#1F5F5B] flex items-center justify-center">
                <Scale className="w-5 h-5" />
              </div>
              <h3 className="font-heading font-bold text-lg text-[#0F1F2E]">Personal Baseline</h3>
              <p className="text-xs text-[#5B6B7A] leading-relaxed">
                Risk is never compared against a generic stranger. It evaluates deviation (μ, σ, historical max) relative to your own verified financial record.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#F5F6F3] border border-[#E4E8E4] space-y-3">
              <div className="w-10 h-10 rounded-xl bg-[#E3F0EE] text-[#1F5F5B] flex items-center justify-center">
                <Eye className="w-5 h-5" />
              </div>
              <h3 className="font-heading font-bold text-lg text-[#0F1F2E]">Explainable Signals</h3>
              <p className="text-xs text-[#5B6B7A] leading-relaxed">
                No black box. Every score contribution is mapped into three clear columns: What changed, Why does it matter, and What can I independently verify.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 4-Step Strip */}
      <section className="px-6 lg:px-12 py-16 max-w-7xl mx-auto space-y-12">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h2 className="text-2xl sm:text-3xl font-heading font-extrabold text-[#0F1F2E]">
            How Fingaurd AI Protects You
          </h2>
          <p className="text-xs sm:text-sm text-[#5B6B7A]">
            A seamless pre-commitment check in four transparent steps.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { step: '01', title: 'Import or Log', desc: 'Add past investments via CSV or simple manual entries to build your baseline.' },
            { step: '02', title: 'Input Proposed Transfer', desc: 'Enter proposed amount, recipient entity, and optional communication text.' },
            { step: '03', title: 'Algorithmic Risk Fusion', desc: 'Calculates escalation ratio, z-score, velocity, and optional NLP indicators.' },
            { step: '04', title: 'Pause & Verify Checklist', desc: 'Independent verification protocol with SEBI, MCA, and RBI alert registries.' },
          ].map((item, idx) => (
            <div key={idx} className="p-6 rounded-2xl bg-white border border-[#E4E8E4] shadow-xs space-y-2 relative">
              <span className="text-3xl font-black font-heading text-[#C9A24A]/40 font-tabular">{item.step}</span>
              <h4 className="font-heading font-bold text-base text-[#0F1F2E]">{item.title}</h4>
              <p className="text-xs text-[#5B6B7A] leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Trust & Privacy Section */}
      <section className="px-6 lg:px-12 py-14 bg-[#E3F0EE]/50 border-t border-[#E4E8E4]">
        <div className="max-w-4xl mx-auto text-center space-y-4">
          <div className="w-10 h-10 rounded-full bg-[#1F5F5B] text-white flex items-center justify-center mx-auto">
            <Lock className="w-5 h-5" />
          </div>
          <h3 className="text-xl font-heading font-extrabold text-[#0F1F2E]">
            Trust, Consent, and Responsible AI Architecture
          </h3>
          <p className="text-xs sm:text-sm text-[#5B6B7A] leading-relaxed">
            Fingaurd AI strictly does not connect to bank accounts, UPI apps, or credit bureaus. Communication analysis only runs with explicit opt-in consent. The output is never a fraud verdict about an individual, but a behavioural safety signal to empower you before irreversible commitments.
          </p>
          <div className="pt-2 text-[11px] font-semibold text-[#1F5F5B] uppercase tracking-wider">
            Prototype score — not validated. This is not financial advice and not a fraud verdict.
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[#E4E8E4] bg-white px-6 lg:px-12 py-8 text-center text-xs text-[#5B6B7A]">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <span>Fingaurd AI © 2026. Academic Prototype for SE CSE-AIML Mini Project.</span>
          <div className="flex items-center gap-6">
            <Link to="/about" className="hover:text-[#0F1F2E] transition-colors">Responsible AI</Link>
            <Link to="/privacy" className="hover:text-[#0F1F2E] transition-colors">Privacy & Audit</Link>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
