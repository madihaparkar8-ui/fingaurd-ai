import React, { useEffect, useState } from 'react';
import { journeyService } from '../services/api';
import { Journey, JourneyEvent } from '../types';
import { formatINR, formatDate } from '../utils/formatters';
import {
  Milestone, Calendar, ArrowRight,
  TrendingUp, Award, Clock
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

export const JourneyPage: React.FC = () => {
  const [journey, setJourney] = useState<Journey | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchJourney = async () => {
      try {
        setLoading(true);
        const data = await journeyService.getMyJourney();
        setJourney(data);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchJourney();
  }, []);

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-10 bg-gray-200 rounded-xl w-52" />
        <div className="h-24 bg-gray-200 rounded-2xl" />
        <div className="h-96 bg-gray-200 rounded-2xl" />
      </div>
    );
  }

  const events = journey?.events || [];
  const barData = events.map((ev, i) => ({
    name: `Step ${i + 1}`,
    stepRatio: ev.stepRatio || 1.0,
    amount: ev.amount,
    entity: ev.entityName,
  }));

  return (
    <div className="space-y-8">
      {/* Title */}
      <div>
        <h1 className="text-2xl font-heading font-black tracking-tight text-[#0F1F2E] flex items-center gap-2">
          <Milestone className="w-6 h-6 text-[#1F5F5B]" />
          Decision Journey Replay
        </h1>
        <p className="text-xs text-[#5B6B7A]">
          Reconstruct the psychological sequence of commitments, step ratios, and behavioral transition tags.
        </p>
      </div>

      {/* Stats Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-4 rounded-xl bg-white border border-[#E4E8E4] shadow-xs">
          <div className="text-[10px] uppercase font-bold text-[#5B6B7A]">Total Events</div>
          <div className="text-xl font-black font-heading text-[#0F1F2E] font-tabular mt-0.5">
            {journey?.eventCount || 0}
          </div>
        </div>

        <div className="p-4 rounded-xl bg-white border border-[#E4E8E4] shadow-xs">
          <div className="text-[10px] uppercase font-bold text-[#5B6B7A]">Total Exposure</div>
          <div className="text-xl font-black font-heading text-[#0F1F2E] font-tabular mt-0.5">
            {formatINR(journey?.totalExposure || 0)}
          </div>
        </div>

        <div className="p-4 rounded-xl bg-white border border-[#E4E8E4] shadow-xs">
          <div className="text-[10px] uppercase font-bold text-[#5B6B7A]">Max Single</div>
          <div className="text-xl font-black font-heading text-[#0F1F2E] font-tabular mt-0.5">
            {formatINR(journey?.maxSingleCommitment || 0)}
          </div>
        </div>

        <div className="p-4 rounded-xl bg-white border border-[#E4E8E4] shadow-xs">
          <div className="text-[10px] uppercase font-bold text-[#5B6B7A]">Mean (μ)</div>
          <div className="text-xl font-black font-heading text-[#0F1F2E] font-tabular mt-0.5">
            {formatINR(journey?.mean || 0)}
          </div>
        </div>

        <div className="p-4 rounded-xl bg-white border border-[#E4E8E4] shadow-xs">
          <div className="text-[10px] uppercase font-bold text-[#5B6B7A]">Std Dev (σ)</div>
          <div className="text-xl font-black font-heading text-[#0F1F2E] font-tabular mt-0.5">
            {formatINR(journey?.standardDeviation || 0)}
          </div>
        </div>

        <div className="p-4 rounded-xl bg-white border border-[#E4E8E4] shadow-xs">
          <div className="text-[10px] uppercase font-bold text-[#5B6B7A]">Journey Duration</div>
          <div className="text-xl font-black font-heading text-[#0F1F2E] font-tabular mt-0.5">
            {journey?.durationDays || 0} Days
          </div>
        </div>
      </div>

      {/* Mini Step-Ratio Chart */}
      <div className="bg-white p-6 rounded-fin border border-[#E4E8E4] shadow-fin-card space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-heading font-extrabold text-sm text-[#0F1F2E]">
              Consecutive Escalation Multipliers (Step Ratio)
            </h3>
            <p className="text-xs text-[#5B6B7A]">
              Ratios ≥ 2.0× indicate rapid behavioral stepping.
            </p>
          </div>
        </div>

        <div className="h-44 w-full">
          {barData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={barData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#5B6B7A' }} />
                <YAxis tick={{ fontSize: 11, fill: '#5B6B7A' }} />
                <Tooltip
                  formatter={(val: any) => [`${val}× previous`, 'Step Ratio']}
                  contentStyle={{ borderRadius: '12px', border: '1px solid #E4E8E4', fontSize: '12px' }}
                />
                <Bar dataKey="stepRatio" fill="#1F5F5B" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center text-xs text-[#5B6B7A]">
              No journey steps recorded.
            </div>
          )}
        </div>
      </div>

      {/* Horizontal / Vertical Animated Timeline */}
      <div className="space-y-4">
        <h3 className="font-heading font-extrabold text-base text-[#0F1F2E]">
          Sequential Decision Pathway
        </h3>

        <div className="relative pl-6 lg:pl-0">
          {/* Vertical line on small screens */}
          <div className="lg:hidden absolute left-2.5 top-0 bottom-0 w-0.5 bg-[#E4E8E4]" />

          {/* Cards container */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {events.map((ev: JourneyEvent, idx: number) => {
              const isLast = idx === events.length - 1;
              const hasReturn = ev.returnAmount && ev.returnAmount > 0;

              return (
                <div
                  key={ev.investmentId}
                  className={`p-5 rounded-2xl bg-white border transition-all relative ${
                    isLast
                      ? 'border-[#1F5F5B] ring-2 ring-[#E3F0EE] shadow-fin-hover'
                      : 'border-[#E4E8E4] shadow-fin-card'
                  }`}
                >
                  {/* Step index badge */}
                  <div className="flex items-center justify-between pb-3 border-b border-[#E4E8E4] mb-3">
                    <span className="text-xs font-bold text-[#5B6B7A] uppercase tracking-wider flex items-center gap-1.5">
                      <span className="w-5 h-5 rounded-full bg-[#E3F0EE] text-[#1F5F5B] flex items-center justify-center font-bold text-[10px]">
                        {idx + 1}
                      </span>
                      Step {idx + 1}
                    </span>
                    <span className="text-[11px] text-[#5B6B7A] flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {formatDate(ev.investedOn)}
                    </span>
                  </div>

                  {/* Entity and Amount */}
                  <div className="space-y-1">
                    <h4 className="font-bold text-sm text-[#0F1F2E] truncate">
                      {ev.entityName}
                    </h4>
                    <div className="text-2xl font-black font-heading text-[#0F1F2E] font-tabular">
                      {formatINR(ev.amount)}
                    </div>
                  </div>

                  {/* Payout highlight */}
                  {hasReturn && (
                    <div className="mt-3 p-2 rounded-lg bg-[#E6F2EA] text-[#5FA37A] text-[11px] font-semibold flex items-center gap-1.5">
                      <Award className="w-3.5 h-3.5" />
                      Apparent Return Received: {formatINR(ev.returnAmount)}
                    </div>
                  )}

                  {/* Step ratio tag */}
                  {idx > 0 && (
                    <div className="mt-2 text-[11px] text-[#5B6B7A] flex items-center gap-1">
                      <TrendingUp className="w-3 h-3 text-[#C9A24A]" />
                      <span>Multiplier vs prior: <strong>{ev.stepRatio}×</strong></span>
                    </div>
                  )}

                  {/* Behavioral Transition Badges */}
                  {ev.badges && ev.badges.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-[#E4E8E4] flex flex-wrap gap-1.5">
                      {ev.badges.map((badge, bIdx) => (
                        <span
                          key={bIdx}
                          className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#FBF1DB] text-[#D9A441] border border-[#F0D49C]"
                        >
                          {badge}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}

            {events.length === 0 && (
              <div className="col-span-4 p-12 text-center text-xs text-[#5B6B7A] bg-white rounded-2xl border border-[#E4E8E4]">
                No journey steps available. Log investments or load a demo journey from the menu.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default JourneyPage;
