package com.fingaurd.controller;

import com.fingaurd.model.AuditEvent;
import com.fingaurd.model.User;
import com.fingaurd.service.AuditService;
import com.fingaurd.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/audit")
public class AuditController {

    private final AuditService auditService;
    private final UserService userService;

    public AuditController(AuditService auditService, UserService userService) {
        this.auditService = auditService;
        this.userService = userService;
    }

    @GetMapping
    public ResponseEntity<List<AuditEvent>> getAuditEvents(@AuthenticationPrincipal UserDetails userDetails) {
        User user = userService.getUserByEmail(userDetails.getUsername());
        List<AuditEvent> list = auditService.getUserAuditEvents(user.getUserId());
        return ResponseEntity.ok(list);
    }
}
