package com.fingaurd.dto.response;

import java.util.ArrayList;
import java.util.List;

public class CsvImportResultResponse {

    private int totalRows;
    private int importedCount;
    private int failedCount;
    private List<String> errors = new ArrayList<>();

    public CsvImportResultResponse() {}

    public CsvImportResultResponse(int totalRows, int importedCount, int failedCount, List<String> errors) {
        this.totalRows = totalRows;
        this.importedCount = importedCount;
        this.failedCount = failedCount;
        this.errors = errors != null ? errors : new ArrayList<>();
    }

    public int getTotalRows() {
        return totalRows;
    }

    public void setTotalRows(int totalRows) {
        this.totalRows = totalRows;
    }

    public int getImportedCount() {
        return importedCount;
    }

    public void setImportedCount(int importedCount) {
        this.importedCount = importedCount;
    }

    public int getFailedCount() {
        return failedCount;
    }

    public void setFailedCount(int failedCount) {
        this.failedCount = failedCount;
    }

    public List<String> getErrors() {
        return errors;
    }

    public void setErrors(List<String> errors) {
        this.errors = errors;
    }
}
