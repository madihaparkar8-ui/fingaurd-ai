package com.fingaurd.service;

import com.fingaurd.dto.request.AnalyseRequest;
import com.fingaurd.model.*;
import com.fingaurd.repository.*;
import jakarta.annotation.PostConstruct;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Service
public class DemoSeedService {

    public static final String DEMO_EMAIL = "demo@fingaurd.ai";
    public static final String DEMO_PASSWORD = "Demo@1234";

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final InvestmentRepository investmentRepository;
    private final JourneyRepository journeyRepository;
    private final RiskReportRepository riskReportRepository;
    private final RiskSignalRepository riskSignalRepository;
    private final AuditService auditService;
    private final RiskAnalysisService riskAnalysisService;

    public DemoSeedService(UserRepository userRepository,
                           PasswordEncoder passwordEncoder,
                           InvestmentRepository investmentRepository,
                           JourneyRepository journeyRepository,
                           RiskReportRepository riskReportRepository,
                           RiskSignalRepository riskSignalRepository,
                           AuditService auditService,
                           RiskAnalysisService riskAnalysisService) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.investmentRepository = investmentRepository;
        this.journeyRepository = journeyRepository;
        this.riskReportRepository = riskReportRepository;
        this.riskSignalRepository = riskSignalRepository;
        this.auditService = auditService;
        this.riskAnalysisService = riskAnalysisService;
    }

    @PostConstruct
    public void initDemoAccount() {
        if (!userRepository.existsByEmail(DEMO_EMAIL)) {
            User demoUser = new User("Rahul Sharma", DEMO_EMAIL, passwordEncoder.encode(DEMO_PASSWORD), Role.USER);
            userRepository.save(demoUser);
            loadPresetJourney(demoUser, "TRUST_TO_COMMITMENT");
        }
    }

    @Transactional
    public void loadPresetJourney(User user, String presetType) {
        // Clear past investments, reports, and journey for this user to reload fresh preset
        List<RiskReport> pastReports = riskReportRepository.findByJourney_User_UserIdOrderByCreatedAtDesc(user.getUserId());
        for (RiskReport r : pastReports) {
            riskSignalRepository.deleteAll(riskSignalRepository.findByRiskReport_ReportId(r.getReportId()));
        }
        riskReportRepository.deleteAll(pastReports);
        investmentRepository.deleteByUser_UserId(user.getUserId());
        journeyRepository.deleteByUser_UserId(user.getUserId());

        LocalDate now = LocalDate.now();

        switch (presetType != null ? presetType.toUpperCase().trim() : "TRUST_TO_COMMITMENT") {
            case "NORMAL" -> {
                // Modest, regular balanced investments to reputable funds
                investmentRepository.saveAll(List.of(
                        new Investment(user, "HDFC Nifty 50 Index Fund", new BigDecimal("15000.00"), now.minusDays(90), "MUTUAL_FUND", null, InvestmentStatus.ACTIVE),
                        new Investment(user, "ICICI Prudential Bluechip", new BigDecimal("20000.00"), now.minusDays(60), "MUTUAL_FUND", null, InvestmentStatus.ACTIVE),
                        new Investment(user, "SBI Large & Midcap Fund", new BigDecimal("25000.00"), now.minusDays(30), "MUTUAL_FUND", null, InvestmentStatus.ACTIVE),
                        new Investment(user, "Axis Small Cap Fund", new BigDecimal("20000.00"), now.minusDays(10), "MUTUAL_FUND", null, InvestmentStatus.ACTIVE)
                ));
            }
            case "GRADUAL" -> {
                // Progressive step-ups
                investmentRepository.saveAll(List.of(
                        new Investment(user, "Vortex Capital Advisory", new BigDecimal("10000.00"), now.minusDays(45), "EQUITY", null, InvestmentStatus.ACTIVE),
                        new Investment(user, "Vortex Capital Advisory", new BigDecimal("20000.00"), now.minusDays(30), "EQUITY", null, InvestmentStatus.ACTIVE),
                        new Investment(user, "Vortex Capital Advisory", new BigDecimal("40000.00"), now.minusDays(15), "EQUITY", null, InvestmentStatus.ACTIVE),
                        new Investment(user, "Vortex Capital Advisory", new BigDecimal("80000.00"), now.minusDays(5), "EQUITY", null, InvestmentStatus.ACTIVE)
                ));
            }
            case "SUDDEN" -> {
                // Sudden escalation jump
                investmentRepository.saveAll(List.of(
                        new Investment(user, "BlueSky Digital Wealth", new BigDecimal("10000.00"), now.minusDays(60), "SCHEME", null, InvestmentStatus.ACTIVE),
                        new Investment(user, "BlueSky Digital Wealth", new BigDecimal("12000.00"), now.minusDays(40), "SCHEME", null, InvestmentStatus.ACTIVE),
                        new Investment(user, "BlueSky Digital Wealth", new BigDecimal("15000.00"), now.minusDays(20), "SCHEME", null, InvestmentStatus.ACTIVE)
                ));
            }
            case "REPEATED_ENTITY" -> {
                // High concentration to single entity
                investmentRepository.saveAll(List.of(
                        new Investment(user, "Quantum FX Prime", new BigDecimal("25000.00"), now.minusDays(35), "FOREX", null, InvestmentStatus.ACTIVE),
                        new Investment(user, "Quantum FX Prime", new BigDecimal("35000.00"), now.minusDays(25), "FOREX", null, InvestmentStatus.ACTIVE),
                        new Investment(user, "Quantum FX Prime", new BigDecimal("45000.00"), now.minusDays(15), "FOREX", null, InvestmentStatus.ACTIVE),
                        new Investment(user, "Quantum FX Prime", new BigDecimal("60000.00"), now.minusDays(5), "FOREX", null, InvestmentStatus.ACTIVE)
                ));
            }
            default -> { // "TRUST_TO_COMMITMENT" - The Golden Scenario
                // 1. ₹20,000 -> (apparent return received ₹24,000, RETURNED)
                // 2. ₹30,000
                // 3. ₹50,000
                // 4. ₹1,00,000, all to Apex Wealth Advisory over about 30 days
                LocalDate d1 = now.minusDays(30);
                LocalDate d2 = now.minusDays(20);
                LocalDate d3 = now.minusDays(10);
                LocalDate d4 = now;

                investmentRepository.saveAll(List.of(
                        new Investment(user, "Apex Wealth Advisory", new BigDecimal("20000.00"), d1, "EQUITY", new BigDecimal("24000.00"), InvestmentStatus.RETURNED),
                        new Investment(user, "Apex Wealth Advisory", new BigDecimal("30000.00"), d2, "EQUITY", null, InvestmentStatus.ACTIVE),
                        new Investment(user, "Apex Wealth Advisory", new BigDecimal("50000.00"), d3, "EQUITY", null, InvestmentStatus.ACTIVE),
                        new Investment(user, "Apex Wealth Advisory", new BigDecimal("100000.00"), d4, "EQUITY", null, InvestmentStatus.ACTIVE)
                ));

                // Pre-generate the golden pre-commitment check report (₹4,00,000 proposed, communication enabled with no indicators)
                // So the dashboard is immediately populated upon first login!
                AnalyseRequest goldenCheck = new AnalyseRequest(
                        new BigDecimal("400000.00"),
                        now,
                        "Apex Wealth Advisory",
                        "Hi Rahul, congratulations on your previous returns! Let us know when you'd like to allocate your next tranche.",
                        true
                );
                riskAnalysisService.analyseProposedCommitment(user, goldenCheck);
            }
        }

        auditService.recordEvent(user, user.getEmail(), "LOAD_DEMO_JOURNEY", presetType, "SUCCESS");
    }
}
